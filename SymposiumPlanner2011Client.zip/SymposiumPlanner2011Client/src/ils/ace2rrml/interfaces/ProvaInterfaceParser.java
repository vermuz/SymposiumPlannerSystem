package ils.ace2rrml.interfaces;

import ils.ace2rrml.ACE2ReactionRuleML;
import ils.ace2rrml.util.ProjectUtil;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class ProvaInterfaceParser {
	public static ProvaInterfaceParser INSTANCE = new ProvaInterfaceParser();
	private String configFilePath;
	private InputStream is = null;
	private Source xmlSource = null;
	private Source xslSource = null;
	private TransformerFactory tFactory = TransformerFactory.newInstance();
	private Transformer transformer = null;
	public final String QUERYBASE = "http://attempto.ifi.uzh.ch/ws/ape/apews.perl?";

	// XML namespace for Reaction RuleML
	public final String XSI_NS = "http://www.w3.org/2001/XMLSchema-instance";

	public final String RRML_NS = "http://www.ruleml.org/0.91/xsd";

	public final String SCHEMA_INSTANCE = "http://www.ruleml.org/0.91/xsd http://ibis.in.tum.de/research/ ReactionRuleML/0.2/rr.xsd";

	public String toProvaInterface(Element signatureElement) {
		String interfaceString = "interface(";
		String interfaceDefinition = "", parameterTypeDefinition = "", annotation = "";
		List<Element> elements = signatureElement.elements();
		for (int i = 0; i < elements.size(); i++) {
			Element ele = elements.get(i);
			if (ele.getName().equalsIgnoreCase("meta")) {
				annotation = ele.selectSingleNode("Atom/Data").getText()
						.trim();
			} else if (ele.getName().equalsIgnoreCase("oid")) {
				interfaceDefinition = ele.elementText("Ind") + "(";
				parameterTypeDefinition = interfaceDefinition;
			} else if (ele.getName().equalsIgnoreCase("Expr")) {
				interfaceDefinition += parserExprDefinition(ele) + ",";
				parameterTypeDefinition += parserExprTypeDefinition(ele) + ",";
			} else if (ele.getName().equalsIgnoreCase("Var")) {
				interfaceDefinition += ele.getText().trim() + ",";
				if (ele.attributeValue("mode").equalsIgnoreCase("+"))
					parameterTypeDefinition += "\"+\",";
				else if (ele.attributeValue("mode").equalsIgnoreCase("-"))
					parameterTypeDefinition += "\"-\",";
				else if (ele.attributeValue("mode").equalsIgnoreCase(
						"?"))
					parameterTypeDefinition += "\"?\",";
			}
		}

		interfaceDefinition = interfaceDefinition.substring(0,
				interfaceDefinition.length() - 1);
		interfaceDefinition += ")";

		parameterTypeDefinition = parameterTypeDefinition.substring(0,
				parameterTypeDefinition.length() - 1);
		parameterTypeDefinition += ")";

		interfaceString = "interface(" + interfaceDefinition + ","
				+ parameterTypeDefinition + "," + "\"" + annotation + "\").";
		return interfaceString;
	}

	private String parserExprTypeDefinition(Element ele1) {
		String exprTypeDefinition = "";
		List<Element> elements = ele1.elements();
		for (int i = 0; i < elements.size(); i++) {
			if (i == 0) {
				exprTypeDefinition = elements.get(i).getText().trim() + "(";
			} else {
				Element ele = elements.get(i);
				if (ele.attributeValue("mode").equalsIgnoreCase("+"))
					exprTypeDefinition += "\"+\",";
				else if (ele.attributeValue("mode").equalsIgnoreCase("-"))
					exprTypeDefinition += "\"-\",";
				else if (ele.attributeValue("mode").equalsIgnoreCase(
						"?"))
					exprTypeDefinition += "\"?\",";
			}
		}
		exprTypeDefinition = exprTypeDefinition.substring(0, exprTypeDefinition
				.length() - 1);
		exprTypeDefinition += ")";
		return exprTypeDefinition;
	}

	private String parserExprDefinition(Element ele1) {
		String expr = "";
		List<Element> elements = ele1.elements();
		for (int i = 0; i < elements.size(); i++) {
			if (i == 0) {
				expr = elements.get(i).getText().trim() + "(";
			} else {
				Element ele = elements.get(i);
				if (ele.getName().equalsIgnoreCase("Expr")) {
					expr += parserExprDefinition(ele) + ",";
				} else {
					expr += ele.getText().trim() + ",";
				}
			}
		}
		expr = expr.substring(0, expr.length() - 1);
		expr += ")";
		return expr;
	}

	public String toProvaInterfaces() {
		String interfaces = "";
		try {
			Document doc = new SAXReader().read(new File(configFilePath));
			List<Element> list = doc.getRootElement().elements();
			for (int i = 0; i < list.size(); i++) {
				interfaces += toProvaInterface(list.get(i)) + "\n";
			}
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return interfaces;
	}

	private ProvaInterfaceParser() {
		this.configFilePath = getProjectDir() + "conf" + File.separator
				+ "prova-interfaces.xml";
	}

	public static String getProjectDir() {
		String parentFile = ACE2ReactionRuleML.class.getResource("/").getFile()
				.toString();
		File serverDir = (new File(parentFile)).getParentFile().getParentFile();
		parentFile = serverDir.getAbsolutePath().replaceAll("%20", " ");
		return (new StringBuilder(String.valueOf(parentFile.replaceAll("%20",
				" ")))).append(File.separator).toString();
	}

	public List<ProvaInterface> getProvaInterfaces() {
		List<ProvaInterface> interfaces = new ArrayList();
		Document doc = getDocument();
		List<Element> list = doc.getRootElement().elements();
		for (int i = 0; i < list.size(); i++) {
			Element ele = list.get(i);
			ProvaInterface inf = new ProvaInterface();
			inf.setAnnotation(ele.selectSingleNode("meta/Atom/Data").getText());
			inf.setName(ele.selectSingleNode("oid/Ind").getText());
			inf.setAgentName(ele.attributeValue("agent"));
			interfaces.add(inf);
		}
		return interfaces;
	}

	public List<ProvaInterface> getProvaInterfaces(String agentName) {
		List<ProvaInterface> interfaces = new ArrayList();
		Document doc = getDocument();
		if (agentName.endsWith("All"))
			return getProvaInterfaces();
		List<Element> list = doc.selectNodes("//signature[@agent='" + agentName
				+ "']");
		for (int i = 0; i < list.size(); i++) {
			Element ele = list.get(i);
			ProvaInterface inf = new ProvaInterface();
			inf.setAnnotation(ele.selectSingleNode("meta/Atom/Data").getText());
			inf.setName(ele.selectSingleNode("oid/Ind").getText());
			inf.setAgentName(ele.attributeValue("agent"));
			interfaces.add(inf);
		}
		return interfaces;
	}

	public List getAgents() {
		List agents = new ArrayList();
		Document doc = getDocument();
		List<Element> list = doc.getRootElement().elements();
		for (int i = 0; i < list.size(); i++) {
			Element ele = list.get(i);
			if (!agents.contains(ele.attributeValue("agent")))
				agents.add(ele.attributeValue("agent"));
		}
		return agents;
	}

	public String provaInterface2Html(String interfaceName) {
		String[] temps = interfaceName.split(":");
		String agent = temps[0].trim();
		interfaceName = temps[1].trim();
		List agents = getDocument().selectNodes(
				"/signatures/signature[@agent='" + agent + "']");
		Element interfaceElement = null;
		for (int i = 0; i < agents.size(); i++) {
			Element agentElement = (Element) agents.get(i);
			if (agentElement.selectSingleNode("oid/Ind").getText().trim().equalsIgnoreCase(interfaceName)) {
				interfaceElement = agentElement;
				break;
			}
		}
		if (interfaceElement == null)
			return "Interal Error!";
		// Element interfaceElement = (Element) getDocument().selectSingleNode(
		// "/interfaces/interface[rel='" + interfaceName + "']");
		String htmlContent = "<table><tr><td height=\"30\"><span class=\"STYLE4\">&nbsp;&nbsp;&nbsp;&nbsp;Prova Interface Description: "
				+ interfaceElement.selectSingleNode("meta/Atom/Data").getText()
				+ ".</span></td></tr>";
		List<Element> list = interfaceElement.elements();
		for (int i = 0; i < list.size(); i++) {
			Element ele = list.get(i);
			if (ele.getName().equalsIgnoreCase("Expr"))
				htmlContent += exprElementToHtml(ele, "&nbsp;&nbsp;");
			else if (ele.getName().equalsIgnoreCase("Var"))
				htmlContent += indElementToHtml(ele, "&nbsp;&nbsp;");
		}
		htmlContent += "</table>";
		return htmlContent;
	}

	private String exprElementToHtml(Element element, String space) {
		String exprContent = space
				+ "<tr><td><table width=\"100%\"><tr><td  height=\"30\">"
				+ element.element("Fun").attributeValue("meta")
				+ "</td></tr>";
		List<Element> list = element.elements();
		for (int i = 0; i < list.size(); i++) {
			Element ele = list.get(i);
			if (ele.getName().equalsIgnoreCase("Expr"))
				exprContent += exprElementToHtml(ele, space
						+ "&nbsp;&nbsp;&nbsp;&nbsp;");
			if (ele.getName().equalsIgnoreCase("Var"))
				exprContent += indElementToHtml(ele, space
						+ "&nbsp;&nbsp;&nbsp;&nbsp;");
		}
		exprContent += "</table></td></tr>";
		return exprContent;
	}

	private String indElementToHtml(Element ele, String space) {
		String indContent = "<tr><td height=\"30\">" + space;
		String value = "";
		if (ele.attribute("default") != null)
			value = ele.attributeValue("default");
		if (ele.attribute("candiates") == null) {
			indContent += ele.getText().trim()
					+ ":&nbsp;&nbsp;<input class=\"input1\"  size=\"48\" type=\"text\" name=\""
					+ ele.getText().trim() + "\" value=\"" + value
					+ "\"/>&nbsp;&nbsp;&nbsp;&nbsp;<span class=\"STYLE4\">("
					+ ele.attributeValue("meta") + ")</span>";
		} else {
			indContent += ele.getText().trim() + ":&nbsp;&nbsp;";
			indContent += "<select  class=\"input1\" name=\"" + ele.getText().trim()
					+ "\">";
			String[] candidates = ele.attributeValue("candiates").split(";");
			for (int i = 0; i < candidates.length; i++) {
				if (candidates[i].equals(ele.attributeValue("default"))) {
					if (candidates[i].indexOf(":") == -1)
						indContent += "<option value=\"" + candidates[i]
								+ "\" selected=\"selected\">" + candidates[i]
								+ "</option>";
					else {
						String[] temps = candidates[i].split(":");
						indContent += "<option value=\"" + temps[1]
								+ "\" selected=\"selected\">" + temps[0]
								+ "</option>";
					}
				} else {
					if (candidates[i].indexOf(":") == -1)
						indContent += "<option value=\"" + candidates[i]
								+ "\">" + candidates[i] + "</option>";
					else {
						String[] temps = candidates[i].split(":");
						indContent += "<option value=\"" + temps[1] + "\">"
								+ temps[0] + "</option>";
					}
				}
			}
			indContent += "</select>&nbsp;&nbsp;&nbsp;&nbsp;<span class=\"STYLE4\">("
					+ ele.attributeValue("meta") + ")</span>";
		}
		indContent += "</td></tr>";
		return indContent;
	}

	public Document provaInterface2RRuleMLAtom(String interfaceName,
			String xsltFilePath) {
		String[] temps = interfaceName.split(":");
		String agent = temps[0].trim();
		interfaceName = temps[1].trim();
		List agents = getDocument().selectNodes(
				"/signatures/signature[@agent='" + agent + "']");
		Element interfaceElement = null;
		for (int i = 0; i < agents.size(); i++) {
			Element agentElement = (Element) agents.get(i);
			if (agentElement.selectSingleNode("oid/Ind").getText().trim().equalsIgnoreCase(interfaceName)) {
				interfaceElement = agentElement;
				break;
			}
		}

		String rruleMLContent = "";
		try {
			InputStream in = null;
			if (in == null) {
				// read xslt from file given a relative path
				in = new FileInputStream(xsltFilePath);
			}

			xslSource = new StreamSource(in); // XSLT Source

			// Get the XML input
			String message = interfaceElement.asXML();

			if (message != null && message.length() > 0)
				is = new ByteArrayInputStream(message.getBytes());

			xmlSource = new StreamSource(is); // XML Source
			// transform XML message into Prova RMessage
			transformer = tFactory.newTransformer(xslSource);

			// Perform the transformation.
			StringWriter provaMessage = new StringWriter();
			transformer.transform(xmlSource, new StreamResult(provaMessage));

			// Extract complex objects from String
			rruleMLContent = provaMessage.toString()
					.replaceAll("type=\"\"", "");

			Document rrmlDoc = DocumentHelper.createDocument();
			Element root = rrmlDoc.addElement("RuleML", RRML_NS);
			root.addAttribute("xsi:schemaLocation", SCHEMA_INSTANCE);
			root.addAttribute("xmlns:xsi", XSI_NS);

			Element msgEl = root.addElement("Message", RRML_NS);
			msgEl.addAttribute("mode", "outbound");
			msgEl.addAttribute("directive", "query-sync");

			Element msgOidEl = msgEl.addElement("oid", RRML_NS);
			Element msgOidInd = msgOidEl.addElement("Ind", RRML_NS);
			msgOidInd.setText(interfaceElement.attributeValue("agent"));

			Element protocolEl = msgEl.addElement("protocol", RRML_NS);
			Element protocolInd = protocolEl.addElement("Ind", RRML_NS);
			protocolInd.setText("esb");

			Element senderEl = msgEl.addElement("sender", RRML_NS);
			Element senderInd = senderEl.addElement("Ind", RRML_NS);
			senderInd.setText("User");

			Element contentEl = msgEl.addElement("content", RRML_NS);
			Element atom = DocumentHelper.parseText(rruleMLContent)
					.getRootElement();
			contentEl.add(atom);
			return rrmlDoc;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public String toRRuleML(HttpServletRequest request) {
		Document doc = provaInterface2RRuleMLAtom(request
				.getParameter("interface"), getProjectDir() + "conf"
				+ File.separator + "provaInterface2HTML.xslt");
		List<Element> inds = doc
				.selectNodes("//*[local-name()='Ind' and namespace-uri()='"
						+ RRML_NS + "']");

		for (int i = 0; i < inds.size(); i++) {
			Element ind = inds.get(i);
			if (request.getParameter(ind.getText().trim()) != null) {
				String temp = request.getParameter(ind.getText().trim());
				temp = temp.replaceAll("@", "AT");
				temp = temp.replaceAll("\\.", "DOT");
				ind.setText(temp);
			}
		}

		List<Element> vars = doc
				.selectNodes("//*[local-name()='Var' and namespace-uri()='"
						+ RRML_NS + "']");

		for (int i = 0; i < vars.size(); i++) {
			Element ind = vars.get(i);
			ind.setText(ind.getTextTrim());
		}

		List<Element> funs = doc
				.selectNodes("//*[local-name()='Fun' and namespace-uri()='"
						+ RRML_NS + "']");

		for (int i = 0; i < funs.size(); i++) {
			Element fun = funs.get(i);
			fun.setText(fun.getTextTrim());
		}

		return ProjectUtil.doc2String(doc);
	}

	public Document getDocument() {
		try {
			return new SAXReader().read(new File(configFilePath));
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public static void main(String[] args) {
		ProvaInterfaceParser parser = new ProvaInterfaceParser();
		System.out.println(parser.toProvaInterfaces());
		// System.out.println(parser.provaInterface2Html("SymposiumPlannerSystem:submission"));
	}
}
