package ils.ace2rrml.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;


public class LexiconParser {
	
	public static List getNouns(){
		List nouns = new ArrayList();
		String regex = "noun_mass\\([^,]*,";
		String content = "";
		try {
			HttpClient client = new HttpClient();
			GetMethod method = new GetMethod("http://de.dbpedia.org/redirects/ruleml/ruleml2011.prog");
			method.setFollowRedirects(true);

			// Execute the GET method
			int statusCode = client.executeMethod(method);
			if (statusCode != -1) {
				content = method.getResponseBodyAsString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Pattern pattern = Pattern.compile(regex);
		Matcher m = pattern.matcher(content);
		while (m.find()) {
			String temp = m.group().substring(10,m.group().length()-1);
			if(temp.startsWith("'")||temp.startsWith("\""))
				temp = temp.substring(1);
			if(temp.endsWith("'")||temp.endsWith("\""))
				temp = temp.substring(0,temp.length()-1);
			nouns.add(temp);
			System.out.println(temp);
		}
		return nouns;
	}
	

}
