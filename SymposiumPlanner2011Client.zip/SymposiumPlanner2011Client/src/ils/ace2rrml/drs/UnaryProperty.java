package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.Map;

/**
 * Instances of this class represent unary properties as provided by the DRS of
 * the APE web service.
 * 
 * @author paba
 * 
 */

public class UnaryProperty extends DrsProperty {

	protected UnaryProperty(String ref, String adjective, PropertyDegree degree) {
		super(ref, adjective, degree);
	}

	/**
	 * Used for cloning only!
	 * 
	 * @param objectReference
	 * @param object
	 * @param adjective
	 * @param degree
	 */

	protected UnaryProperty(String objectReference, DrsObject object,
			String adjective, PropertyDegree degree) {
		super(objectReference, adjective, degree);
	}


	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsProperty changeObject1(DrsObject object1) {
		return new UnaryProperty(object1.getReference(), object1,
				this.adjective, this.degree);
	}

	/* (non-Javadoc)
	 * @see ils.ace2rrml.drs.DrsElement#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject obj1 = objectsMap.get(this.getObject1Ref());
		if (obj1 == null) {
			objectsMap.put(this.getObject1Ref(), DrsObject.fromProperty(this));
		} else if (!obj1.isAnonymous()){
			obj1.addProperty(this);
			this.setObject1(obj1);
		}
	}

	/* (non-Javadoc)
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map, java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,Map<String, DrsPredicate> predicatesMap){
		try {
			if (this.getObject1() == null) {
				DrsObject obj = objectsMap.get(this.getObject1Ref());
				if (obj == null) {

					throw new TransformationException(
							"The property \""
									+ this.getAdjective()
									+ "\" does not reference to a valid primary object!");
				} else {
					this.setObject1(obj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
