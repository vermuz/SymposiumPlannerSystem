package ils.ace2rrml.drs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GroupObject extends DrsObject {

		private final List<DrsObject> objects;
		private final int expectedCount;

		public GroupObject(String ref, int expectedCount) {
			super(ref);
			this.expectedCount = expectedCount;

			this.objects = new ArrayList<DrsObject>(expectedCount);
		}

		/**
		 * {@inheritDoc}
		 */

		@Override
		public String getName() {
			return getReference();
		}

		/**
		 * This method provides a list of the objects that are the members of
		 * this object.
		 * 
		 * @return a list of this object's members.
		 */

		@Override
		public List<DrsObject> getObjects() {
			return Collections.unmodifiableList(this.objects);
		}

		/**
		 * This method adds the given object to the members of this object.
		 * 
		 * @param member
		 *            the object to add.
		 */
		@Override
		public void addObject(DrsObject member) {
			objects.add(member);
		}


}
