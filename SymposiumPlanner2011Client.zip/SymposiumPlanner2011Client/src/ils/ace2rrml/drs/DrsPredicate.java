package ils.ace2rrml.drs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.Element;


/**
 * Instances of subclasses of this abstract class are supposed to represent
 * predicates as provided from the DRS output from the APE web service.
 * 
 * @author paba
 * 
 */
public abstract class DrsPredicate extends DrsAtom {
	
	  protected final String reference;

    /**
     * This is a list of adverbs referring to this predicate.
     */

    protected final List<DrsAdverb> adverbs;

    /**
     * This is a list of prepositional phrases referring to this predicate.
     */

    protected final List<DrsPrepositionalPhrase> prepositionalPhrases;

    /**
     * The verb describing this predicate.
     */
    protected final String verb;

    /**
     * The reference to the subject this predicate is referring to.
     */
    protected final String subjectReference;

    /**
     * The subject this predicate is referring to. This should be the object
     * {@link #subjectReference} is referencing to.
     */
    protected DrsObject subject = null;

    /**
     * Construct a predicate from all the ingredients all predicates have in
     * common
     * 
     * @param reference
     *            the reference to this predicate (s. {@link #getReference()}).
     * @param verb
     *            the predicate's verb (s. {@link #getVerb()}).
     * @param subjectReference
     *            the reference to the predicate's subject (s.
     *            {@link #getSubjectRef()}).
     */

    public DrsPredicate(String reference, String verb, String subjectReference)
            throws IllegalArgumentException {
        if (verb == null) {
            throw new IllegalArgumentException(
                    "A DRS predicate's verb must not be null!");
        }
        if (subjectReference == null) {
            throw new IllegalArgumentException(
                    "A DRS predicate's subject reference must not be null!");
        }
        this.verb = verb;
        this.subjectReference = subjectReference;
        this.reference = reference;

        this.subject = null;

        this.adverbs = new LinkedList<DrsAdverb>();
        this.prepositionalPhrases = new LinkedList<DrsPrepositionalPhrase>();
    }

    /**
     * Used for cloning only!
     * 
     * @param reference
     * @param adverbs
     * @param prepositionalPhrases
     * @param verb
     * @param subjectReference
     * @param subject
     * @throws IllegalArgumentException
     */

    public DrsPredicate(String reference, List<DrsAdverb> adverbs,
            List<DrsPrepositionalPhrase> prepositionalPhrases, String verb,
            String subjectReference, DrsObject subject)
            throws IllegalArgumentException {
        this.adverbs = new ArrayList<DrsAdverb>(adverbs.size());
        for (DrsAdverb adv : adverbs) {
            this.adverbs.add(adv.changePredicate(this));
        }
        this.prepositionalPhrases = new ArrayList<DrsPrepositionalPhrase>(
                prepositionalPhrases.size());
        for (DrsPrepositionalPhrase pp : prepositionalPhrases) {
            this.prepositionalPhrases.add(pp.changePredicate(this));
        }
        this.verb = verb;
        this.subjectReference = subjectReference;
        this.subject = subject;
        this.reference = reference;
    }

    /**
     * This method parses a "predicate" XML element from an DRS XML document
     * into a {@link DrsPredicate} object.
     * 
     * @param formulaElement
     *            the XML element which is supposed to be a "predicate" element
     * @return the predicated obtained from the input XML element
     */

    public static DrsAtom parseFromXml(Element formulaElement) {
        String ref = formulaElement.attributeValue("ref");
        String verb = formulaElement.attributeValue("verb");
        String subj = formulaElement.attributeValue("subj");
        String obj = formulaElement.attributeValue("obj");
        if (obj == null) {
            // intransitive predicate
            return new IntransitivePredicate(ref, verb, subj);
        } else {
            String indobj = formulaElement.attributeValue("indobj");
            if (indobj == null) {
                // transitive predicate
                return new TransitivePredicate(ref, verb, subj, obj);
            } else {
                // ditrasitive predicate
                return new DitransitivePredicate(ref, verb, subj, obj, indobj);
            }
        }
    }

    /**
     * This method adds the given adverb to the list of adverbs of this
     * predicate.
     * 
     * @param adverb
     *            the adverb to add.
     */

    public void addAdverb(DrsAdverb adverb) {
        this.adverbs.add(adverb);
    }

    /**
     * This method provides a list of all the adverbs of this predicate.
     * 
     * @return a list of all the adverbs of this predicate.
     */

    public List<DrsAdverb> getAdverbs() {
        return Collections.unmodifiableList(this.adverbs);
    }

    /**
     * This method adds the given prepositional phrase to the list of
     * prepositional phrases of this predicate.
     * 
     * @param prepositionalPhrase
     *            the prepositional phrase to add.
     */

    public void addPrepositionalPhrase(
            DrsPrepositionalPhrase prepositionalPhrase) {
        this.prepositionalPhrases.add(prepositionalPhrase);
    }

    /**
     * This method provides a list of all the prepositional phrases of this
     * predicate.
     * 
     * @return a list of all the prepositional phrases of this predicate.
     */

    public List<DrsPrepositionalPhrase> getPrepositionalPhrases() {
        return Collections.unmodifiableList(this.prepositionalPhrases);
    }

    /**
     * This method provides this predicate's subject. This is supposed to be the
     * object the value of {@link #getSubjectRef()} is referencing to.
     * 
     * @see #getSubjectRef()
     * @see #setSubject(DrsObject)
     * @return the subject of this predicate.
     */
    public DrsObject getSubject() {
        return subject;
    }

    protected abstract DrsPredicate changePrepositionalPhrases(
            List<DrsPrepositionalPhrase> propostionalPhrases);

    /**
     * This method provides a copy of this predicate changing the subject to the
     * given one; all other elements of this predicate are preserved.
     * 
     * @param subject
     *            the new subject
     * @return the copy with the changed subject.
     */

    protected abstract DrsPredicate changeSubject(DrsObject subject);


    /**
     * This method provides a list containing a separate copy of this predicate
     * for each member of the members of the group subject, provided the subject
     * is really a group object. If not a singleton list containing this
     * predicate is returned.
     * 
     * @return a list of copies for each member of the subject group.
     */

    public List<DrsPredicate> splitOnSubject() {
        DrsObject sub = this.getSubject();
        if (sub.isGroupObject()) {
            List<DrsObject> members = sub.getObjects();
            List<DrsPredicate> copies = new ArrayList<DrsPredicate>(members
                    .size());
            for (DrsObject member : members) {
                copies.add(this.changeSubject(member));
            }
            return copies;
        } else {
            List<DrsPredicate> id = new ArrayList<DrsPredicate>(1);
            id.add(this);
            return id;
        }
    }
    
    public List<DrsPredicate> splitOnDrsObject(){
    	return splitOnSubject();
    }

    public List<DrsPredicate> splitOnPrepositionalPhrases() {
        List<DrsPredicate> copies = new LinkedList<DrsPredicate>();
        DrsPrepositionalPhrase[] newpps = new DrsPrepositionalPhrase[this.prepositionalPhrases
                .size()];
        DrsPrepositionalPhrase[] oldpps = new DrsPrepositionalPhrase[this.prepositionalPhrases
                .size()];
        oldpps = this.prepositionalPhrases.toArray(oldpps);
        splitOnPrepositionalPhrase(this, copies, oldpps, 0, newpps);
        return copies;
    }

    private static void splitOnPrepositionalPhrase(DrsPredicate oldPred,
            List<DrsPredicate> copies, DrsPrepositionalPhrase[] oldpps,
            int curr, DrsPrepositionalPhrase[] newpps) {
        if (curr == newpps.length) {
            copies.add(oldPred
                    .changePrepositionalPhrases(Arrays.asList(newpps)));
        } else {
            DrsObject obj = oldpps[curr].getObject();
            if (obj.isGroupObject()) {
                for (DrsObject member : obj.getObjects()) {
                    newpps[curr] = oldpps[curr].changeObject(member);
                    splitOnPrepositionalPhrase(oldPred, copies, oldpps,
                            curr + 1, newpps);
                }
            } else {
                newpps[curr] = oldpps[curr];
                splitOnPrepositionalPhrase(oldPred, copies, oldpps, curr + 1,
                        newpps);
            }
        }
    }
   

    /**
     * This method sets the subject of this predicate. This is supposed to be
     * the object the value of {@link #getSubjectRef()} is referencing to.
     * 
     * @see #getSubject()
     * @see #getSubjectRef()
     * @param subject
     * 
     * @throws IllegalStateException
     *             if the subject is already set.
     * @throws IllegalArgumentException
     *             if the <code>subject</code> parameter is <code>null</code>.
     */

    public void setSubject(DrsObject subject) throws IllegalStateException,
            IllegalArgumentException {
        if (this.subject != null) {
            throw new IllegalStateException("The subject is already set!");
        }
        if (subject == null) {
            throw new IllegalArgumentException(
                    "The subject must not be set to null!");
        }
        this.subject = subject;
    }

    /**
     * This method provides the verb of this predicate.
     * 
     * @return the verb of this predicate.
     */

    public String getVerb() {
        return verb;
    }

    /**
     * This method provides the reference to the subject this predicate is
     * referring to.
     * 
     * @return the reference to this predicate's subject.
     */

    public String getSubjectRef() {
        return subjectReference;
    }



    /**
     * This method provides the reference to this predicate's indirect object,
     * provided this is a ditransitive predicate.
     * 
     * @see #getIndirectObject()
     * @see #setIndirectObject(DrsObject)
     * 
     * @return the reference to this predicate's indirect object.
     * @throws UnsupportedOperationException
     *             if this is not a ditransitive predicate
     */

    public String getIndirectObjectRef() throws UnsupportedOperationException {
        throw new UnsupportedOperationException(
                "This is not a ditransitive predicate!");
    }


    /**
     * This method provides a string that is supposed to be used as an
     * identifier for a RuleML predicate representing this predicate.
     * 
     * @return the RuleML identifier for this predicate.
     */

    public String toRuleMLIdentifier() throws UnsupportedOperationException {
        return get3rdPersonVerb() + getRuleMLIdentifierForModifier();
    }

    /**
     * This method tries to provide the correct 3rd person form of this
     * predicate's verb.
     * 
     * @return the 3rd person form of this predicate's verb.
     */

    private String get3rdPersonVerb() {
        if (this.verb.equals("be")) {
            return "is";
        } else if (this.verb.equals("have")) {
            return "has";
        } else {
            return verb + "s";
        }
    }

    /**
     * This method provides a string that is supposed to be used to be used as a
     * suffix for a RuleML predicate that is modified by the adverbs and the
     * prepositional phrases of this predicate.
     * 
     * @return the identifier suffix for this predicate's modifier, i.e., the
     *         adverbs and the prepositional phrases.
     */

    public String getRuleMLIdentifierForModifier()
            throws UnsupportedOperationException {
    	String adv = "_";
    	for(DrsAdverb adverb: this.adverbs){
    		adv=adv+adverb.toRuleMLIdentifier()+"_";
    	}
    	adv = adv.substring(0, adv.length()-1);
    	
    	String prep = "_";
    	for(DrsPrepositionalPhrase prepositional: this.prepositionalPhrases){
    		prep=prep+prepositional.toRuleMLIdentifier()+"_";
    	}
    	prep = prep.substring(0, prep.length()-1);
        return adv + prep;
    }

	public String getReference() {
		return reference;
	}
    
    
       
}
