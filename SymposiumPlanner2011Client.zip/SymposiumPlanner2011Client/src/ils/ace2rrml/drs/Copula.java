package ils.ace2rrml.drs;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Copula extends DrsObject {


	/**
     * The property this copula object represents.
     */
    private final List<DrsProperty> properties;

    /**
     * Constructs a copula object with the given property.
     * 
     * @param property
     *            the property that is supposed to be wrapped by an object.
     */
    public Copula(DrsProperty property) {
        super(property.getObject1Ref());
        this.properties = new LinkedList<DrsProperty>();
        this.properties.add(property);
    }

    /**
     * {@inheritDoc}
     */

    @Override
    public String getName() {
        return this.getReference();
    }

    /**
     * This method provides the properties this object represents in the
     * form of an unmodifiable list.
     * 
     * @return the property a copula object represents.
     */

    @Override
    public List<DrsProperty> getProperties() {
        return Collections.unmodifiableList(this.properties);
    }

    /**
     * This method adds a property to this copula object.
     * 
     * @param property
     *            the property to add.
     */

    @Override
    public void addProperty(DrsProperty property) {
        this.properties.add(property);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    void substituteProperty(DrsProperty property,
            List<DrsProperty> substitutes) throws IllegalStateException {
        if (this.properties.remove(property)) {
            this.properties.addAll(substitutes);
        } else {
            throw new IllegalStateException(
                    "The given property that should be substituted is not present!");
        }
    }

}
