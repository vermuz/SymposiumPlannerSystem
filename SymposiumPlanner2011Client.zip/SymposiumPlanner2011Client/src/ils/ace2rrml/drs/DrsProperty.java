package ils.ace2rrml.drs;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Element;

/**
 * Instances of subclasses of this abstract class are supposed to represent
 * properties of DRS as produced by the APE web service.
 * 
 * @author paba
 * 
 */
public abstract class DrsProperty extends DrsAtom {

	/**
	 * This is the reference to this property's primary object.
	 */

	protected final String objectReference;

	/**
	 * This is the primary object {@link #objectReference} references to.
	 */

	protected DrsObject object;

	/**
	 * The adjective of the property.
	 */
	protected final String adjective;

	/**
	 * The degree of the property.
	 */
	protected final PropertyDegree degree;

	/**
	 * Constructs a property from all the ingredients.
	 * 
	 * @param objectRef
	 *            the reference to the primary object of this property (s.
	 *            {@link #getObject1Ref()}).
	 * @param adjective
	 *            the adjective describing this property (s.
	 *            {@link #getAdjective()}).
	 * @param degree
	 *            the degree of this property (s. {@link #getDegree()}).
	 */

	protected DrsProperty(String objectRef, String adjective,
			PropertyDegree degree) throws IllegalArgumentException {
		if (objectRef == null) {
			throw new IllegalArgumentException(
					"A DRS property's primary object reference must not be null!");
		}
		if (adjective == null) {
			throw new IllegalArgumentException(
					"A DRS property's adjective must not be null!");
		}
		if (degree == null) {
			throw new IllegalArgumentException(
					"A DRS property's degree must not be null!");
		}

		this.objectReference = objectRef;
		this.adjective = adjective;
		this.degree = degree;

		this.object = null;
	}

	/**
	 * Used for cloning only.
	 * 
	 * @param objectReference
	 * @param object
	 * @param adjective
	 * @param degree
	 */

	protected DrsProperty(String objectReference, DrsObject object,
			String adjective, PropertyDegree degree) {
		this.objectReference = objectReference;
		this.object = object;
		this.adjective = adjective;
		this.degree = degree;
	}

	/**
	 * This method parses the given XML element which is supposes to be a
	 * "property" element of a DRS XML document from the APE web service.
	 * 
	 * @param pE
	 *            the XML "property" element which is supposed to be parsed
	 * @return the parsed property
	 * @throws IllegalArgumentException
	 *             if the XML element has not the expected form (i.e. it does
	 *             not encode a DRS property)
	 */

	public static DrsAtom parseFromXml(Element pE)
			throws IllegalArgumentException {
		String ref = pE.attributeValue("ref");
		String adj = pE.attributeValue("adj");
		String obj = pE.attributeValue("obj");
		PropertyDegree degree = PropertyDegree.fromString(pE
				.attributeValue("degree"));

		if (obj != null) {
			return new BinaryProperty(ref, adj, degree, obj);
		} else if (pE.attributeValue("obj1") != null) {
			PropertyComparisonTarget comptarget = PropertyComparisonTarget
					.fromString(pE.attributeValue("comptarget"));
			String obj2 = pE.attributeValue("obj2");
			return new TernaryProperty(ref, adj, degree,
					pE.attributeValue("obj1"), comptarget, obj2);
		} else {
			return new UnaryProperty(ref, adj, degree);
		}
	}
	
	
	//The owner object in relationship predicate is seemed as a property
	public static DrsProperty parseFromObject(DrsObject obj){
		return new UnaryProperty(obj.getReference(), obj.getName(), PropertyDegree.fromString("pos"));
	}

	/**
	 * This method provides this property's describing adjective.
	 * 
	 * @return the adjective describing this property.
	 */

	public String getAdjective() {
		return adjective;
	}

	/**
	 * This method provides the degree of this property.
	 * 
	 * @return the degree of this property.
	 */

	public PropertyDegree getDegree() {
		return degree;
	}

	/**
	 * This method provides the comparison target of this property, provided
	 * that this property is a ternary one.
	 * 
	 * @return the comparison target of this property.
	 * @throws UnsupportedOperationException
	 *             if this is not a ternary property.
	 */

	public PropertyComparisonTarget getComparisonTarget()
			throws UnsupportedOperationException {
		throw new UnsupportedOperationException(
				"This is not a ternary property!");
	}

	/**
	 * This method provides a list containing a separate copy of this property
	 * for each member of the primary object, provided it is a group object.
	 * Otherwise a singleton list containing this property is returned.
	 * 
	 * @return a list of copies for each member of the primary object group.
	 */

	public List<DrsProperty> splitOnObject1() {
		DrsObject obj1 = this.getObject1();
		if (obj1.isGroupObject()) {
			List<DrsObject> members = obj1.getObjects();
			List<DrsProperty> copies = new ArrayList<DrsProperty>(
					members.size());
			for (DrsObject member : members) {
				copies.add(this.changeObject1(member));
			}
			return copies;
		} else {
			List<DrsProperty> id = new ArrayList<DrsProperty>(1);
			id.add(this);
			return id;
		}
	}

	public List<DrsProperty> splitOnObject() {
		return splitOnObject1();
	}

	protected abstract DrsProperty changeObject1(DrsObject object1);

	/**
	 * This method provides a string that is supposed to be used as an
	 * identifier for a RuleML predicate representing this property.
	 * 
	 * @return the RuleML identifier for this property.
	 */

	public String toRuleMLIdentifier() {
		if (this.degree == PropertyDegree.pos) {
			return this.adjective;
		} else if (this.degree == PropertyDegree.pos_as) {
			return "as_" + this.adjective + "_as";
		} else if (this.degree == PropertyDegree.comp) {
			return "more_" + this.adjective;
		} else if (this.degree == PropertyDegree.comp_than) {
			return "more_" + this.adjective + "_than";
		} else if (this.degree == PropertyDegree.sup) {
			return "most_" + this.adjective;
		} else {
			throw new RuntimeException("Enum constant \"" + this.degree
					+ "\" is not supported!");
		}
	}

	/**
	 * This method provides the reference to the primary object of this property
	 * (i.e. the subject).
	 * 
	 * @see #getObject1()
	 * @return the reference to this property's primary object.
	 */

	public String getObject1Ref() {
		return objectReference;
	}

	/**
	 * This method is supposed to provide the primary object of this property
	 * (i.e. the subject).
	 * 
	 * @see #getObject1Ref()
	 * @see #setObject1(DrsObject)
	 * @return the property's primary object.
	 */

	public DrsObject getObject1() {
		return object;
	}

	/**
	 * This method sets the primary object of this property. This object is
	 * supposed to be the one that is referenced to by the reference as provided
	 * by {@link #getObject1Ref()}.
	 * 
	 * @see #getObject1()
	 * @param object
	 *            the object that should be set as this property's primary
	 *            object.
	 * 
	 * @throws IllegalStateException
	 *             if the primary object is already set.
	 * @throws IllegalArgumentException
	 *             if the <code>object</code> parameter is <code>null</code>.
	 */

	public void setObject1(DrsObject object) throws IllegalStateException,
			IllegalArgumentException {
		if (this.object != null) {
			throw new IllegalStateException("The object is already set!");
		}
		if (object == null) {
			throw new IllegalArgumentException(
					"The object must not be set to null!");
		}
		this.object = object;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#toRuleMLElement(org.dom4j.Element,
	 * org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement)
			throws UnsupportedOperationException {
		this.getObject1().toRuleMLElement(atom);
	}

}
