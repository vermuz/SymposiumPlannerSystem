package ils.ace2rrml.drs;

import java.util.Map;

import org.dom4j.Element;

/**
 * Instances of subclasses of this class are supposed to represent elements of a
 * DRS (e.g. objects, predicates etc.).
 * 
 * @author paba
 * 
 */

public abstract class DrsAtom {

	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
	}

	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
	}

	public void toRuleMLElement(Element atom, Element rootElement) {

	}
}
