package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.Map;

import org.dom4j.Element;

/**
 * Instances of this class represent prepositional phrases as identified by the
 * APE web service.
 * 
 * @author paba
 * 
 */

public class DrsPrepositionalPhrase extends DrsAtom {

	/**
	 * This is the preposition of this prepositional phrase.
	 */
	protected final String prepostion;

	/**
	 * This is the reference to the object this propositional phrase is
	 * referring to.
	 */
	protected final String objectRef;

	/**
	 * This is the object this prepositional phrase is referring to. It is
	 * supposed to be the object referenced by {@link #objectRef}.r
	 */
	protected DrsObject object = null;

	/**
	 * This is the predicate this modifier is modifying. This is supposed to be
	 * the predicate that is referenced by {@link #predicateRef}.
	 */

	protected DrsPredicate predicate;

	protected final String predicateRef;

	public DrsPredicate getPredicate() {
		return predicate;
	}

	public void setPredicate(DrsPredicate predicate) {
		this.predicate = predicate;
	}

	public String getPredicateRef() {
		return predicateRef;
	}

	/**
	 * Constructs a prepositional phrase from all the ingredients
	 * 
	 * @param predicateRef
	 *            the reference to the predicate that is modified by the
	 *            prepositional phrase (s. {@link #getPredicateRef()}).
	 * @param prepostion
	 *            the preposition of the prepositional phrase (s.
	 *            {@link #getPrepostion()}).
	 * @param objectRef
	 *            the reference to the object the prepositional phrase is
	 *            referring to (s. {@link #getObjectRef()}=.
	 */

	public DrsPrepositionalPhrase(String predicateRef, String prepostion,
			String objectRef) {
		this.predicateRef = predicateRef;
		this.prepostion = prepostion;
		this.objectRef = objectRef;
	}

	/**
	 * Used for cloning only!
	 * 
	 * @param predicateRef
	 * @param predicate
	 * @param prepostion
	 * @param objectRef
	 * @param object
	 */
	protected DrsPrepositionalPhrase(String predicateRef,
			DrsPredicate predicate, String prepostion, String objectRef,
			DrsObject object) {
		this.predicateRef = predicateRef;
		this.prepostion = prepostion;
		this.objectRef = objectRef;
		this.object = object;
	}

	DrsPrepositionalPhrase changePredicate(DrsPredicate predicate) {
		return new DrsPrepositionalPhrase(predicate.getReference(), predicate,
				this.prepostion, this.objectRef, this.object);
	}

	DrsPrepositionalPhrase changeObject(DrsObject object) {
		return new DrsPrepositionalPhrase(this.predicateRef, this.predicate,
				this.prepostion, object.getReference(), object);
	}

	/**
	 * This method parses an XML element which is supposed to be an
	 * "modifier_pp" element from a DRS XML document into a
	 * {@link DrsPrepositionalPhrase} object.
	 * 
	 * @param ppEl
	 *            the "modifier_pp" XML element
	 * @return the prepositional phrase obtained from the XML element
	 */

	public static DrsAtom parseFromXml(Element ppEl) {
		String ref = ppEl.attributeValue("ref");
		String prep = ppEl.attributeValue("prep");
		String obj = ppEl.attributeValue("obj");

		return new DrsPrepositionalPhrase(ref, prep, obj);
	}

	/**
	 * This method sets the object that is referred to by this prepositional
	 * phrase. This is supposed to be the object referenced by the value of
	 * {@link #getObjectRef()}.
	 * 
	 * @see #getObjectRef()
	 * @see #setObject(DrsObject)
	 * 
	 * @return the object that is referred to by this prepositional phrase.
	 */

	public DrsObject getObject() {
		return object;
	}

	/**
	 * This method sets the object that is referred to by this prepositional
	 * phrase. This is supposed to be the object referenced by the value of
	 * {@link #getObjectRef()}.
	 * 
	 * @see #getObjectRef()
	 * @see #getObject()
	 * 
	 * @param object
	 *            the object that is referred to by this prepositional phrase
	 * 
	 * @throws IllegalStateException
	 *             if the object is already set.
	 * @throws IllegalArgumentException
	 *             if the <code>object</code> parameter is <code>null</code>.
	 */

	public void setObject(DrsObject object) throws IllegalStateException,
			IllegalArgumentException {
		if (this.object != null) {
			throw new IllegalStateException("The object is already set!");
		}
		if (object == null) {
			throw new IllegalArgumentException(
					"The object must not be set to null!");
		}
		this.object = object;
	}

	/**
	 * This method provides the preposition of this prepositional phrase.
	 * 
	 * @return the preposition of this prepositional phrase
	 */

	public String getPrepostion() {
		return prepostion;
	}

	/**
	 * This method provides the reference to the object this prepositional
	 * phrase is referring to.
	 * 
	 * @see #getObject()
	 * @see #setObject(DrsObject)
	 * 
	 * @return the reference to the object this prepositional phrase is
	 *         referring to.
	 */

	public String getObjectRef() {
		return objectRef;
	}

	/**
	 * This method provides a string that can be used when generating
	 * identifiers for predicates that should be used in a RuleML document.
	 * 
	 * @return the identifier for this preposition.
	 */

	public String toRuleMLIdentifier() {
		return this.prepostion;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject obj = objectsMap.get(this.getObjectRef());
		if (obj == null) {
			objectsMap.put(this.getObjectRef(),
					DrsObject.fromString(this.getObjectRef()));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			DrsPredicate pred = (DrsPredicate) predicatesMap.get(this
					.getPredicateRef());
			if (pred == null) {

				throw new TransformationException(
						"The prepositional phrase involving \""
								+ this.getPrepostion()
								+ "\" does not reference to a valid predicate!");
			} else {
				this.setPredicate(pred);
				pred.addPrepositionalPhrase(this);
			}
			if (this.getObject() == null) {
				DrsObject obj = objectsMap.get(this.getObjectRef());
				if (obj == null) {
					throw new TransformationException(
							"The prepositional phrase involving \""
									+ this.getPrepostion()
									+ "\" does not reference to a valid object!");
				} else {
					this.setObject(obj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
