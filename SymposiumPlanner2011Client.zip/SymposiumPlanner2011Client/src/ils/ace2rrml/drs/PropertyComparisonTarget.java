package ils.ace2rrml.drs;

public enum PropertyComparisonTarget {
    subj, obj;

    public static PropertyComparisonTarget fromString(String str)
            throws IllegalArgumentException {
        for (PropertyComparisonTarget tgt : PropertyComparisonTarget.class
                .getEnumConstants()) {
            if (tgt.name().equals(str)) {
                return tgt;
            }
        }
        throw new IllegalArgumentException("\"" + str
                + "\" is not a supported property comparison target!");
    }
}
