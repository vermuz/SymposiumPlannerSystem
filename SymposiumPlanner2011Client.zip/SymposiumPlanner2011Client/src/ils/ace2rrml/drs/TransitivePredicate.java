package ils.ace2rrml.drs;

import ils.ace2rrml.InterfaceNameDecision;
import ils.ace2rrml.TransformationException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;

public class TransitivePredicate extends DrsPredicate {

	protected final String objectReference;
	protected DrsObject object;

	/**
	 * Construct a predicate from all the ingredients.
	 * 
	 * @param reference
	 *            the reference to this predicate (s. {@link #getReference()}).
	 * @param verb
	 *            the predicate's verb (s. {@link #getVerb()}).
	 * 
	 * @param subjectReference
	 *            the reference to the predicate's subject (s.
	 *            {@link #getSubjectRef()}).
	 * @param objectRef
	 *            the reference to the object of this predicate.
	 */

	public TransitivePredicate(String reference, String verb,
			String subjectReference, String objectRef)
			throws IllegalArgumentException {
		super(reference, verb, subjectReference);
		if (objectRef == null) {
			throw new IllegalArgumentException(
					"A DRS predicate's object reference must not be null!");
		}
		this.objectReference = objectRef;

		this.object = null;
	}

	/**
	 * Used for cloning only.
	 * 
	 * @param reference
	 * @param adverbs
	 * @param prepositionalPhrases
	 * @param verb
	 * @param subjectReference
	 * @param subject
	 * @param objectReference
	 * @param object
	 * @throws IllegalArgumentException
	 */

	protected TransitivePredicate(String reference, List<DrsAdverb> adverbs,
			List<DrsPrepositionalPhrase> prepositionalPhrases, String verb,
			String subjectReference, DrsObject subject, String objectReference,
			DrsObject object) throws IllegalArgumentException {
		super(reference, adverbs, prepositionalPhrases, verb, subjectReference,
				subject);

		this.objectReference = objectReference;
		this.object = object;
	}

	public DrsObject getObject() {
		return this.object;
	}

	public String getObjectRef() {
		return this.objectReference;
	}

	public void setObject(DrsObject object) throws IllegalStateException,
			IllegalArgumentException {
		if (this.object != null) {
			throw new IllegalStateException("The object is already set!");
		}
		if (object == null) {
			throw new IllegalArgumentException(
					"The object must not be set to null!");
		}
		this.object = object;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsPredicate changeSubject(DrsObject subject) {
		return new TransitivePredicate(this.reference, this.adverbs,
				this.prepositionalPhrases, this.verb, subject.getReference(),
				subject, this.objectReference, this.object);
	}

	protected DrsPredicate changeObject(DrsObject object)
			throws UnsupportedOperationException {
		return new TransitivePredicate(this.reference, this.adverbs,
				this.prepositionalPhrases, this.verb, this.subjectReference,
				this.subject, object.getReference(), object);
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsPredicate changePrepositionalPhrases(
			List<DrsPrepositionalPhrase> prepositionalPhrases) {
		return new TransitivePredicate(this.reference, this.adverbs,
				prepositionalPhrases, this.verb, this.subjectReference,
				this.subject, this.objectReference, this.object);
	}

	/**
	 * This method provides a list containing a separate copy of this predicate
	 * for each member of the members of the direct object's group, provided the
	 * direct object is really a group object. If not a singleton list
	 * containing this predicate is returned.
	 * 
	 * @return a list of copies for each member of the direct object group.
	 * @throws UnsupportedOperationException
	 *             if this is neither a transitive nor a ditransitive predicate
	 */

	public List<DrsPredicate> splitOnObject()
			throws UnsupportedOperationException {
		DrsObject obj = this.getObject();
		if (obj.isGroupObject()) {
			List<DrsObject> members = obj.getObjects();
			List<DrsPredicate> copies = new ArrayList<DrsPredicate>(
					members.size());
			for (DrsObject member : members) {
				copies.add(this.changeObject(member));
			}
			return copies;
		} else {
			List<DrsPredicate> id = new ArrayList<DrsPredicate>(1);
			id.add(this);
			return id;
		}
	}

	public List<DrsPredicate> splitOnDrsObject() {
		List<DrsPredicate> predicates = new ArrayList();
		List<DrsPredicate> ps1 = this.splitOnSubject();
		for (DrsPredicate p1 : ps1) {
			List<DrsPredicate> ps2 = ((TransitivePredicate) p1).splitOnObject();
			predicates.addAll(ps2);
		}
		return predicates;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject subj = objectsMap.get(this.getSubjectRef());
		if (subj == null)
			objectsMap.put(this.getSubjectRef(),
					DrsObject.tryExtractAnonymousObject(this.getSubjectRef()));
		else
			this.setSubject(subj);

		DrsObject obj = objectsMap.get(this.getObjectRef());
		if (obj == null)
			objectsMap.put(this.getObjectRef(),
					DrsObject.tryExtractAnonymousObject(this.getObjectRef()));
		else
			this.setObject(obj);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			if (this.getSubject() == null) {
				DrsObject subj = objectsMap.get(this.getSubjectRef());
				if (subj == null) {
					throw new TransformationException("The predicate \""
							+ this.getVerb()
							+ "\" is not referencing to a valid subject!");

				} else {
					this.setSubject(subj);
				}
			}

			if (this.getObject() == null) {
				DrsObject obj = objectsMap.get(this.getObjectRef());
				if (obj == null) {
					throw new TransformationException("The predicate \""
							+ this.getVerb()
							+ "\" is not referencing to a valid direct object!");
				} else {
					this.setObject(obj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#toRuleMLElement(org.dom4j.Element,
	 * org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement) {
		if (this.getSubject().isQuery() && this.getVerb().equals("be")) {// query with is
			atom.element("Rel").setText(getInterfaceName(this.getObject(),this.getSubject()));
			if (this.getObject().isGroupObject()) {
				for (DrsObject obj : this.getObject().getObjects())
					atom.addElement("Var").setText(obj.getName());
			} else if (!this.getObject().isAnonymous()) {
				for (DrsProperty prop : this.getObject().getProperties()) {
					atom.addElement("Ind").setText(prop.getAdjective());
				}
				atom.addElement("Var").setText(this.getObject().getName());
			}else{
				atom.addElement("Var").setText(this.getObject().getName());
			}
		} else if (!this.getSubject().isQuery() && this.getVerb().equals("be")) {// assert with is
			if (this.getObject().getProperties().size() == 1
					&& this.getObject().getProperties().get(0).getDegree()
							.equals(PropertyDegree.fromString("comp_than"))) {
				this.getSubject().toRuleMLElement(atom);
				DrsProperty property = this.getObject().getProperties().get(0);
				atom.element("Rel").setText(property.toRuleMLIdentifier());
				property.toRuleMLElement(atom, contentElement);
			}  else {
				Element parentElement = atom.getParent();
				parentElement.remove(atom);
				Element exprElement = parentElement.addElement("Expr");
				exprElement.addElement("Fun").setText(
						this.getSubject().getName());
				for (DrsProperty property : this.getObject().getProperties()) {
					exprElement.addElement("Ind").setText(
							property.getAdjective());
				}
			}

		} else {// query and assert without is
			this.getSubject().toRuleMLElement(atom);
			if (this.getObject().isGroupObject()) {
				for (DrsObject obj : this.getObject().getObjects()) {
					obj.toRuleMLElement(atom);
				}
			} else {
				this.getObject().toRuleMLElement(atom);
			}

		}

		if (this.getPrepositionalPhrases().size() == 1) {
			this.getPrepositionalPhrases().get(0).getObject()
					.toRuleMLElement(atom);
		}
	}

	private String getInterfaceName(DrsObject object2, DrsObject subject) {
		String temp = "InterfaceNotDecided";
		InterfaceNameDecision decision = new InterfaceNameDecision();
		if (this.getObject().isGroupObject()) {
			for (DrsObject obj : this.getObject().getObjects()){
				if(this.getObject().getObjects().size()==2){
					return decision.getInterfaceName(obj.getName());
				}
				else return temp;
			}
		} else if (!this.getObject().isAnonymous()) {
			temp = decision.getInterfaceName(this.getObject().getName());
			if(temp.equalsIgnoreCase("InterfaceNotDecided"))
				for (DrsProperty pro : this.getObject().getProperties()){
					temp = decision.getInterfaceName(pro.getAdjective());
					if(temp.equalsIgnoreCase("InterfaceNotDecided"))
						continue;
				}
		}
		
		if(temp.equalsIgnoreCase("InterfaceNotDecided")){
			temp = decision.getInterfaceName(subject.getName());
			if(temp.equalsIgnoreCase("InterfaceNotDecided"))
				for (DrsProperty pro : subject.getProperties()){
					temp = decision.getInterfaceName(pro.getAdjective());
					if(temp.equalsIgnoreCase("InterfaceNotDecided"))
						continue;
				}
		}
		
		return temp;
	}

}
