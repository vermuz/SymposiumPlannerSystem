package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationNotSupportedException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.dom4j.Element;

/**
 * Instances of subclasses of this class represent objects of a DRS. These
 * objects can be explicitly created by "object" predicates (noun objects) or by
 * "query" predicates (query objects). Alternatively these objects arise
 * implicitly by "property" predicates (copula objects) or string expressions
 * (anonymous objects).
 * 
 * @author paba
 * 
 */

public abstract class DrsObject extends DrsAtom {
	private boolean isQuery = false;
	private final String reference;
	private DrsObject ownerObject;

	public DrsObject getOwnerObject() {
		return ownerObject;
	}

	public void setOwnerObject(DrsObject ownerObject) {
		this.ownerObject = ownerObject;
	}

	public boolean isQuery() {
		return isQuery;
	}

	public void setQuery(boolean isQuery) {
		this.isQuery = isQuery;
	}

	public boolean isGroupObject() {
		return this instanceof GroupObject;
	}

	/**
	 * Constructs an object with a reference to it.
	 * 
	 * @param reference
	 *            the reference to this object.
	 */

	public DrsObject(String reference) {
		this.reference = reference;
	}

	/**
	 * This method parses the given XML element which is supposed to be a
	 * "object" element from a DRS XML document into a noun object.
	 * 
	 * @see #isNoun()
	 * 
	 * @param objectEl
	 *            the "object" XML element
	 * @return the object obtained from the input XML element
	 * @throws TransformationNotSupportedException
	 *             if the given element does not represent a valid and supported
	 *             object.
	 */

	public static DrsObject parseFromObjectXml(Element objectEl)
			throws TransformationNotSupportedException {
		String ref = objectEl.attributeValue("ref");
		String noun = objectEl.attributeValue("noun");
		if ("na".equals(noun)) {
			// struct="countable" unit="na" numrel="eq"
			String struct = objectEl.attributeValue("struct");
			String unit = objectEl.attributeValue("unit");
			String numrel = objectEl.attributeValue("numrel");
			String num = objectEl.attributeValue("num");

			if ("countable".equals(struct) && "na".equals(unit)
					&& "eq".equals(numrel)) {
				try {
					int count = Integer.parseInt(num);
					return new GroupObject(ref, count);
				} catch (NumberFormatException e) {
					throw new TransformationNotSupportedException(
							"The given object representation is not supported!");
				}
			} else {
				throw new TransformationNotSupportedException(
						"The given object representation is not supported!");
			}

		} else {
			String struct = objectEl.attributeValue("struct");
			if ("countable".equals(struct)) {
				String num = objectEl.attributeValue("num");
				if (isNumeric(num)) {
					return new Definite(ref, noun, num);
				} else {
					throw new TransformationNotSupportedException(
							"Indefinite objects with cardinality > 1 are not supported!");
				}
			}
			return new Noun(ref, noun);
		}

	}

	public static boolean isNumeric(String str) {
		if (str == null) {
			return false;
		}
		boolean result = true;
		for (int i = 0; i < str.length(); i++) {
			char chr = str.charAt(i);
			if (!Character.isDigit(chr) || chr == 46) {
				result = false;
				break;
			}
		}
		return result;
	}

	/**
	 * This method constructs an anonymous object with the given name.
	 * 
	 * @param name
	 *            the object's name.
	 * @return the constructed anonymous object.
	 */

	public static DrsObject fromString(String name) {
		return new Anonymous(name);
	}

	/**
	 * This method tries to extract an anonymous object from a reference string.
	 * If this reference string is of the form "string(<code>name</code>)" an
	 * anonymous object with name <code>name</code> is returned. Otherwise
	 * <code>null</code>.
	 * 
	 * @param ref
	 *            the reference string from which to extract the anonymous
	 *            object.
	 * @return an anonymous object with name <code>name</code> if the reference
	 *         string is of the form "string(<code>name</code>)", otherwise
	 *         <code>null</code>.
	 */

	public static DrsObject tryExtractAnonymousObject(String ref) {
		if (ref.startsWith("string(") && ref.endsWith(")")) {
			return fromString(ref.substring(7, ref.length() - 1));
		} else if (ref.startsWith("named(") && ref.endsWith(")")) {
			return fromString(ref.substring(6, ref.length() - 1));
		} else
			return fromString(ref);
	}

	/**
	 * This method provides a Boolean value indicating whether this object
	 * actually represents an indefinite object.
	 * 
	 * @return <code>true</code> iff this object represents an indefinite
	 *         object.
	 */

	public boolean isDefinite() {
		return this instanceof Definite;
	}

	/**
	 * This method provides a Boolean value that indicates whether this object
	 * actually represents an anonymous object that arose by a string
	 * expression.
	 * 
	 * @return <code>true</code> iff this object represents a "string(...)"
	 *         expression.
	 */
	public boolean isAnonymous() {
		return this instanceof Anonymous;
	}

	/**
	 * This method provides a Boolean value that indicates whether this object
	 * actually represents a noun object, i.e., one which arose from an "object"
	 * predicate.
	 * 
	 * @return <code>true</code> iff this object represents a noun object
	 */

	public boolean isNoun() {
		return this instanceof Noun;
	}

	/**
	 * This method provides the type of this object, provided it is an
	 * indefinite object, i.e. , {@link #isDefinite()} yields <code>true</code>.
	 * 
	 * @return the type of the indefinite object
	 * @throws UnsupportedOperationException
	 *             if this is not an indefinite object, i.e.,
	 *             {@link #isDefinite()} yields <code>false</code>.
	 */

	public String getType() throws UnsupportedOperationException {
		throw new UnsupportedOperationException(
				"This is not an indefinite object!");
	}

	/**
	 * This method provides a list of the objects that are the members of this
	 * object, provided this is actually a group object, i.e. ,
	 * {@link #isGroupObject()} yields <code>true</code>.
	 * 
	 * @return a list of this object's members.
	 * @throws UnsupportedOperationException
	 *             if this is not a group object, i.e., {@link #isGroupObject()}
	 *             yields <code>false</code>.
	 */

	public List<DrsObject> getObjects() throws UnsupportedOperationException {
		throw new UnsupportedOperationException("This is not a group object!");
	}

	/**
	 * This method adds the given object to the members of this object, provided
	 * this is actually a group object, i.e. , {@link #isGroupObject()} yields
	 * <code>true</code>.
	 * 
	 * @param member
	 *            the object to add.
	 * @throws UnsupportedOperationException
	 *             if this is not a group object, i.e., {@link #isGroupObject()}
	 *             yields <code>false</code>.
	 */

	public void addObject(DrsObject member)
			throws UnsupportedOperationException {
		throw new UnsupportedOperationException("This is not a group object!");
	}

	/**
	 * This method provides the noun of this object, provided that this is a
	 * noun object, i.e., {@link #isNoun()} yields <code>true</code>.
	 * 
	 * @return the noun of a noun object.
	 * @throws UnsupportedOperationException
	 *             if this is not a noun object, i.e., {@link #isNoun()} yields
	 *             <code>false</code>.
	 */

	public String getNoun() throws UnsupportedOperationException {
		throw new UnsupportedOperationException(
				"This object is not a noun object!");
	}

	/**
	 * This method provides the properties this object has, provided this is a
	 * copula object, i.e {@link #isCopula()} yields <code>true</code>.
	 * 
	 * @return the properties a copula object has.
	 * @throws UnsupportedOperationException
	 *             if this is not a copula object, i.e., {@link #isCopula()}
	 *             yields <code>false</code>.
	 */

	public List<DrsProperty> getProperties()
			throws UnsupportedOperationException {
		throw new UnsupportedOperationException("This is not a copula object!");
	}

	/**
	 * This method adds a property to this object, provided it is a copula
	 * object, i.e {@link #isCopula()} yields <code>true</code>.
	 * 
	 * @param property
	 *            the property to add.
	 * @throws UnsupportedOperationException
	 *             if this is not a copula object, i.e., {@link #isCopula()}
	 *             yields <code>false</code>
	 */

	public void addProperty(DrsProperty property)
			throws UnsupportedOperationException {
		throw new UnsupportedOperationException("This is not a copula object!");
	}

	/**
	 * This method substitutes the given property by the given properties.
	 * 
	 * @param property
	 *            the property to substitute.
	 * @param substitutes
	 *            list of the properties to replace the old one.
	 * @throws UnsupportedOperationException
	 *             if this is not a copula object, i.e., {@link #isCopula()}
	 *             yields <code>false</code>.
	 * @throws IllegalStateException
	 *             if the given property is not present.
	 */

	void substituteProperty(DrsProperty property, List<DrsProperty> substitutes)
			throws UnsupportedOperationException, IllegalStateException {
		throw new UnsupportedOperationException("This is not a copula object!");
	}

	/**
	 * This method provides the name of this object.
	 * 
	 * @return this object's name.
	 */

	public abstract String getName();

	/**
	 * This method constructs a copula object wrapping the given property.
	 * 
	 * @param property
	 *            the property to wrap.
	 * @return the constructed copula object.
	 */

	public static DrsObject fromProperty(DrsProperty property) {
		return new Copula(property);
	}

	public boolean isCopula() {
		return this instanceof Copula;
	}

	/**
	 * Instances of this class represent indefinite objects, i.e., objects that
	 * are not named.
	 * 
	 * @author paba
	 * 
	 */
	private static class Definite extends DrsObject {

		/**
		 * This is the type of this indefinite object.
		 */
		private final String noun;
		private final String num;

		/**
		 * The property this copula object represents.
		 */
		private final List<DrsProperty> properties;

		/**
		 * Constructs an indefinite object with the given reference and type.
		 * 
		 * @param type
		 *            the type of the indefinite object.
		 * @param reference
		 *            the reference to the indefinite object.
		 */
		private Definite(String reference, String noun, String num) {
			super(reference);
			this.noun = noun;
			this.num = num;
			this.properties = new LinkedList<DrsProperty>();
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public String getName() {
			return noun;
		}

		/**
		 * {@inheritDoc}
		 */

		@Override
		public String getNoun() {
			return noun;
		}

		@Override
		public List<DrsProperty> getProperties() {
			return Collections.unmodifiableList(this.properties);
		}

		/**
		 * This method adds a property to this copula object.
		 * 
		 * @param property
		 *            the property to add.
		 */

		@Override
		public void addProperty(DrsProperty property) {
			this.properties.add(property);
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		void substituteProperty(DrsProperty property,
				List<DrsProperty> substitutes) throws IllegalStateException {
			if (this.properties.remove(property)) {
				this.properties.addAll(substitutes);
			} else {
				throw new IllegalStateException(
						"The given property that should be substituted is not present!");
			}
		}
	}

	public Element getRuleMlTypePredicate(Element contentElement)
			throws UnsupportedOperationException {
		Element atom = contentElement.addElement("Atom");
		atom.addElement("Rel").setText(this.getType());
		this.toRuleMLElement(atom);
		return atom;
	}

	public void toRuleMLElement(Element atom) {
		if (isGroupObject())
			throw new UnsupportedOperationException(
					"Cannot translate a group object into a RuleML object!");
		if (this instanceof Anonymous) {
			Element obj = atom.addElement(isQuery() || isDefinite() ? "Var"
					: "Ind");
			obj.setText(getName());
		} else if (!(this instanceof Anonymous)) {
			if (this.getProperties().size() == 0) {
				atom.addElement("Ind").setText(this.getName());
			} else if (this.getProperties().size() == 1) {
				Element subAtom = atom.addElement("Expr");
				subAtom.addElement("Fun").setText(this.getName());
				subAtom.addElement("Ind").setText(this.getProperties().get(0).getAdjective());
			} else {
				Element obj = atom.addElement("Expr");
				obj.addElement("Fun").setText(this.getName());
				for (DrsProperty prop : this.getProperties()) {
					obj.addElement("Ind").setText(prop.getAdjective());
				}
			}
		}
	}

	/**
	 * Instances of this class represent noun objects, i.e. objects that arose
	 * from "object" predicates of a DRS.
	 * 
	 * @author paba
	 * 
	 */
	private static class Noun extends DrsObject {

		private final List<DrsProperty> properties;
		/**
		 * The noun that is used for this object or null if this represents a
		 * query.
		 */
		private final String noun;

		/**
		 * Constructs an object with the given reference and noun.
		 * 
		 * @param reference
		 *            the reference to this object.
		 * @param noun
		 *            this object's noun.
		 */
		private Noun(String reference, String noun)
				throws IllegalArgumentException {
			super(reference);
			if (noun == null) {
				throw new IllegalArgumentException(
						"An object's noun must not be null!");
			}
			this.noun = noun;
			this.properties = new LinkedList<DrsProperty>();
		}

		/**
		 * Provides the object's noun.
		 * 
		 * @return this object's noun.
		 */
		@Override
		public String getNoun() {
			return noun;
		}

		/**
		 * {@inheritDoc}
		 */

		@Override
		public String getName() {
			return noun;
		}

		/**
		 * This method provides the properties this object represents in the
		 * form of an unmodifiable list.
		 * 
		 * @return the property a copula object represents.
		 */

		@Override
		public List<DrsProperty> getProperties() {
			return Collections.unmodifiableList(this.properties);
		}

		/**
		 * This method adds a property to this copula object.
		 * 
		 * @param property
		 *            the property to add.
		 */

		@Override
		public void addProperty(DrsProperty property) {
			this.properties.add(property);
		}

	}

	/**
	 * Instances of this class represent anonymous objects, i.e., objects which
	 * arose from "string(...)" expressions.
	 * 
	 * @author paba
	 * 
	 */

	private static class Anonymous extends DrsObject {

		/**
		 * This is the name of this anonymous object, i.e., the string inside
		 * the "string(...)" expression which created this object.
		 */
		private final String name;

		/**
		 * Constructs an anonymous object with the given name (usually the
		 * string found in the "string(...)" expression.
		 * 
		 * @param name
		 *            the anonymous objects name.
		 */
		private Anonymous(String name) {
			super(name);
			this.name = name;
		}

		/**
		 * {@inheritDoc}
		 */

		@Override
		public String getName() {
			return name;
		}
	}

	public String getReference() {
		return reference;
	}

}
