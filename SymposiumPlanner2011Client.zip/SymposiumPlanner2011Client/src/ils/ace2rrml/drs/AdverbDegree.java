package ils.ace2rrml.drs;

public enum AdverbDegree {
    pos, comp, sup;

    public static AdverbDegree fromString(String str)
            throws IllegalArgumentException {
        for (AdverbDegree pg : AdverbDegree.class.getEnumConstants()) {
            if (pg.name().equals(str)) {
                return pg;
            }
        }
        throw new IllegalArgumentException("\"" + str
                + "\" is not a supported adverb degree.");
    }
}
