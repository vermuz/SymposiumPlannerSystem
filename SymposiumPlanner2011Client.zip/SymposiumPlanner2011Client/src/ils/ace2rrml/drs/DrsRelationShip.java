package ils.ace2rrml.drs;

import java.util.Map;

import ils.ace2rrml.TransformationException;

import org.dom4j.Element;

public class DrsRelationShip extends DrsAtom {

	protected final String relationship;
	protected String object1Ref = null;
	protected String object2Ref = null;
	protected DrsObject object1 = null;
	protected DrsObject object2 = null;

	public DrsRelationShip(String relationship, String object1Ref,
			String object2Ref) {
		// TODO Auto-generated constructor stub
		if (relationship == null) {
			throw new IllegalArgumentException(
					"The relationship argument must not be null!");
		}
		if (object1Ref == null) {
			throw new IllegalArgumentException(
					"The object argument must not be null!");
		}

		if (object2Ref == null) {
			throw new IllegalArgumentException(
					"The owner object argument must not be null!");
		}
		this.relationship = relationship;
		this.object1Ref = object1Ref;
		this.object2Ref = object2Ref;
	}

	public static DrsAtom parseFromXmlElement(Element ch) {
		// TODO Auto-generated method stub
		String relationship = ch.attributeValue("rel");
		String objectRef1 = ch.attributeValue("obj1");
		String objectRef2 = ch.attributeValue("obj2");
		return new DrsRelationShip(relationship, objectRef1, objectRef2);
	}

	public String getObject1Ref() {
		return object1Ref;
	}

	public void setObject1Ref(String objectRef) {
		this.object1Ref = objectRef;
	}

	public String getObject2Ref() {
		return object2Ref;
	}

	public void setObject2Ref(String ownerObjectRef) {
		this.object2Ref = ownerObjectRef;
	}

	public DrsObject getObject1() {
		return object1;
	}

	public void setObject1(DrsObject object1) {
		this.object1 = object1;
	}

	public DrsObject getObject2() {
		return object2;
	}

	public void setObject2(DrsObject object2) {
		this.object2 = object2;
	}

	public String getRelationship() {
		if(relationship.equals("of"))
			return "is_part_of";
		return relationship;
	}

	/* (non-Javadoc)
	 * @see ils.ace2rrml.drs.DrsElement#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject obj = objectsMap.get(this.getObject1Ref());
		if (obj == null) {
			objectsMap.put(this.getObject1Ref(),
					DrsObject.tryExtractAnonymousObject(this.getObject1Ref()));
		}else
			this.setObject1(obj);

		DrsObject ownerObj = objectsMap.get(this.getObject2Ref());
		if (ownerObj == null) {
			objectsMap.put(this.getObject2Ref(),
					DrsObject.tryExtractAnonymousObject(this.getObject2Ref()));
		}else
			this.setObject2(ownerObj);
	}

	/* (non-Javadoc)
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map, java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			DrsObject object = objectsMap.get(this.getObject1Ref());
			if (object == null) {
				throw new TransformationException(
						"\"relation\" statement does not refer to a valid object!");
			} else
				this.setObject1(object);
			
			DrsObject ownObject = objectsMap.get(this.getObject2Ref());
			if (ownObject == null) {
				throw new TransformationException(
						"\"relation\" statement does not refer to a valid owner object!");
			} else{
				this.setObject2(ownObject);
				object.addProperty(DrsProperty.parseFromObject(ownObject));
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/* (non-Javadoc)
	 * @see ils.ace2rrml.drs.DrsElement#toRuleMLElement(org.dom4j.Element, org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement)
			throws UnsupportedOperationException {
		this.getObject1().toRuleMLElement(atom);
		this.getObject2().toRuleMLElement(atom);
	}

}
