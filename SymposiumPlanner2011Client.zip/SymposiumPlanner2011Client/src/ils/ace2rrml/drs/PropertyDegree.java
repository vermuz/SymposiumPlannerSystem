package ils.ace2rrml.drs;

public enum PropertyDegree {
	pos, pos_as, comp, comp_than, sup;

	public static PropertyDegree fromString(String str)
			throws IllegalArgumentException {
		for (PropertyDegree dg : PropertyDegree.class.getEnumConstants()) {
			if (dg.name().equals(str)) {
				return dg;
			}
		}
		throw new IllegalArgumentException("\"" + str
				+ "\" is not a supported property degree.");
	}
}
