package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;

public class BinaryProperty extends UnaryProperty {

	protected final String object2Reference;
	protected DrsObject object2 = null;

	protected BinaryProperty(String object1Ref, String adjective,
			PropertyDegree degree, String object2Ref)
			throws IllegalArgumentException {
		super(object1Ref, adjective, degree);
		if (object2Ref == null) {
			throw new IllegalArgumentException(
					"A DRS binary property's secondary object reference must not be null!");
		}
		this.object2Reference = object2Ref;
		this.object2 = null;;
	}

	protected BinaryProperty(String objectReference, DrsObject object,
			String adjective, PropertyDegree degree, String object2Reference,
			DrsObject object2) {
		super(objectReference, object, adjective, degree);
		this.object2Reference = object2Reference;
		this.object2 = object2;
	}

	public void setObject2(DrsObject object2) throws IllegalStateException,
			IllegalArgumentException {
		if (this.object2 != null) {
			throw new IllegalStateException(
					"The indirect secondary object is already set!");
		}
		if (object2 == null) {
			throw new IllegalArgumentException(
					"The indirect secondary object must not be set to null!");
		}
		this.object2 = object2;

	}

	public DrsObject getObject2() {
		return object2;
	}

	public String getObject2Ref() {
		return object2Reference;
	}

	protected DrsProperty changeObject2(DrsObject object2) {
		return new BinaryProperty(object2.getReference(), object2,
				this.adjective, this.degree, this.object2Reference,
				this.object2);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsProperty#splitOnObject()
	 */
	public List<DrsProperty> splitOnObject2()
			throws UnsupportedOperationException {
		DrsObject obj2 = this.getObject2();
		if (obj2.isGroupObject()) {
			List<DrsObject> members = obj2.getObjects();
			List<DrsProperty> copies = new ArrayList<DrsProperty>(
					members.size());
			for (DrsObject member : members) {
				copies.add(this.changeObject2(member));
			}
			DrsObject obj1 = this.getObject1();
			if (obj1 != null) {
				obj1.substituteProperty(this, copies);
			}
			return copies;
		} else {
			List<DrsProperty> id = new ArrayList<DrsProperty>(1);
			id.add(this);
			return id;
		}
	}

	public List<DrsProperty> splitOnObject() {
		List<DrsProperty> propertiesCopies = new LinkedList<DrsProperty>();
		List<DrsProperty> ps1 = this.splitOnObject1();
		for (DrsProperty p1 : ps1) {
			List<DrsProperty> ps2 = ((BinaryProperty) p1).splitOnObject2();
			propertiesCopies.addAll(ps2);
		}
		return propertiesCopies;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.UnaryProperty#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject obj1 = objectsMap.get(this.getObject1Ref());
		if (obj1 == null) {
			objectsMap.put(this.getObject1Ref(), DrsObject.fromProperty(this));
		} else if (!obj1.isAnonymous()&&!this.getDegree().equals(PropertyDegree.fromString("comp_than"))) {
			obj1.addProperty(this);
			this.setObject1(obj1);
		}

		DrsObject obj2 = objectsMap.get(this.getObject2Ref());
		if (obj2 == null) {
			objectsMap.put(this.getObject2Ref(), DrsObject.fromProperty(this));
		} else  if (!obj2.isAnonymous()&&!this.getDegree().equals(PropertyDegree.fromString("comp_than"))) {
			obj2.addProperty(this);
			this.setObject2(obj2);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.UnaryProperty#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			if (this.getObject1() == null) {
				DrsObject obj = objectsMap.get(this.getObject1Ref());
				if (obj == null) {
					throw new TransformationException(
							"The property \""
									+ this.getAdjective()
									+ "\" does not reference to a valid primary object!");
				} else {
					this.setObject1(obj);
				}
			}

			if (this.getObject2() == null) {
				DrsObject obj = objectsMap.get(this.getObject2Ref());
				if (obj == null) {
					throw new TransformationException(
							"The property \""
									+ this.getAdjective()
									+ "\" does not reference to a valid secondary object!");
				} else {
					this.setObject2(obj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsProperty#toRuleMLElement(org.dom4j.Element,
	 * org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement)
			throws UnsupportedOperationException {
//		this.getObject1().toRuleMLElement(atom);
		System.out.println("AAAAAAAAAAAAAAAAAA:"+this.getObject2().getClass());
		this.getObject2().toRuleMLElement(atom);
	}

}
