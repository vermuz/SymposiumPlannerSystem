package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;

/**
 * Instances of this class represent ternary properties as provided by the DRS
 * output from the APE web service.
 * 
 * @author paba
 * 
 */
public class TernaryProperty extends BinaryProperty {
	protected final String object3Reference;
	protected DrsObject object3 = null;
	protected final PropertyComparisonTarget comparisonTarget;

	/**
	 * Constructs a ternary property from all the ingredients.
	 * 
	 * @param object1Ref
	 *            the reference to the primary object.
	 * @param adjective
	 *            the adjective describing this property.
	 * @param degree
	 *            the degree of this property.
	 * @param object2Reference
	 *            the reference to the secondary object.
	 * @param comparisonTarget
	 *            the comparison target of this property.
	 * @param object3Reference
	 *            the reference to the ternary object.
	 */
	TernaryProperty(String object1Ref, String adjective, PropertyDegree degree,
			String object2Reference, PropertyComparisonTarget comparisonTarget,
			String object3Reference) throws IllegalArgumentException {
		super(object1Ref, adjective, degree, object2Reference);

		if (object3Reference == null) {
			throw new IllegalArgumentException(
					"A DRS ternary property's tertiary object reference must not be null!");
		}
		if (comparisonTarget == null) {
			throw new IllegalArgumentException(
					"A DRS ternary property's comparison target must not be null!");
		}
		this.object3Reference = object3Reference;
		this.comparisonTarget = comparisonTarget;

		this.object3 = null;
	}

	/**
	 * Used for cloning only!
	 * 
	 * @param objectReference
	 * @param object
	 * @param adjective
	 * @param degree
	 * @param object2Reference
	 * @param object2
	 * @param object3Reference
	 * @param object3
	 * @param comparisonTarget
	 */
	protected TernaryProperty(String objectReference, DrsObject object,
			String adjective, PropertyDegree degree, String object2Reference,
			DrsObject object2, String object3Reference, DrsObject object3,
			PropertyComparisonTarget comparisonTarget) {
		super(objectReference, object, adjective, degree, object2Reference,
				object2);
		this.object3Reference = object3Reference;
		this.object3 = object3;
		this.comparisonTarget = comparisonTarget;
	}

	public DrsObject getObject3() {
		return object3;
	}

	public void setObject3(DrsObject object3) throws IllegalStateException,
			IllegalArgumentException {
		if (this.object3 != null) {
			throw new IllegalStateException(
					"The tertiary object is already set!");
		}
		if (object3 == null) {
			throw new IllegalArgumentException(
					"The tertiary object must not be set to null!");
		}
		this.object3 = object3;
	}

	public String getObject3Ref() {
		return object3Reference;
	}

	public List<DrsProperty> splitOnObject3()
			throws UnsupportedOperationException {
		DrsObject obj3 = this.getObject3();
		if (obj3.isGroupObject()) {
			List<DrsObject> members = obj3.getObjects();
			List<DrsProperty> copies = new ArrayList<DrsProperty>(
					members.size());
			for (DrsObject member : members) {
				copies.add(this.changeObject3(member));
			}
			DrsObject obj1 = this.getObject1();
			if (obj1 != null) {
				obj1.substituteProperty(this, copies);
			}
			return copies;
		} else {
			List<DrsProperty> id = new ArrayList<DrsProperty>(1);
			id.add(this);
			return id;
		}
	}

	public List<DrsProperty> splitOnObject() {
		List<DrsProperty> propertiesCopies = new LinkedList<DrsProperty>();
		List<DrsProperty> ps1 = this.splitOnObject1();
		for (DrsProperty p1 : ps1) {
			List<DrsProperty> ps2 = ((BinaryProperty) p1).splitOnObject2();
			for (DrsProperty p2 : ps2) {
				List<DrsProperty> ps3 = ((TernaryProperty) p2).splitOnObject3();
				propertiesCopies.addAll(ps3);
			}
		}
		return propertiesCopies;
	}

	/**
	 * This method provides the comparison target of this property.
	 * 
	 * @return the comparison target of this property.
	 */
	@Override
	public PropertyComparisonTarget getComparisonTarget() {
		return comparisonTarget;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsProperty changeObject1(DrsObject object1) {
		return new TernaryProperty(object1.getReference(), object1,
				this.adjective, this.degree, this.object2Reference,
				this.object2, this.object3Reference, this.object3,
				this.comparisonTarget);
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsProperty changeObject2(DrsObject object2) {
		return new TernaryProperty(this.objectReference, this.object,
				this.adjective, this.degree, object2.getReference(), object2,
				this.object3Reference, this.object3, this.comparisonTarget);
	}

	protected DrsProperty changeObject3(DrsObject object3) {
		return new TernaryProperty(this.objectReference, this.object,
				this.adjective, this.degree, this.object2Reference,
				this.object2, object3.getReference(), object3,
				this.comparisonTarget);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.BinaryProperty#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject obj1 = objectsMap.get(this.getObject1Ref());
		if (obj1 == null) {
			objectsMap.put(this.getObject1Ref(),
					DrsObject.fromProperty(this));
		} else  if (!obj1.isAnonymous()&&!this.getDegree().equals(PropertyDegree.fromString("comp_than"))) {
			obj1.addProperty(this);
			this.setObject1(obj1);
		}

		DrsObject obj2 = objectsMap.get(this.getObject2Ref());
		if (obj2 == null) {
			objectsMap.put(this.getObject2Ref(),
					DrsObject.fromProperty(this));
		} else  if (!obj2.isAnonymous()&&!this.getDegree().equals(PropertyDegree.fromString("comp_than"))) {
			obj2.addProperty(this);
			this.setObject2(obj2);
		}

		DrsObject obj3 = objectsMap.get(this.getObject3Ref());
		if (obj3 == null) {
			objectsMap.put(this.getObject3Ref(),DrsObject.fromProperty(this));
		} else if (!obj3.isAnonymous()&&!this.getDegree().equals(PropertyDegree.fromString("comp_than"))) {
			obj3.addProperty(this);
			this.setObject3(obj3);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.BinaryProperty#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			if (this.getObject1() == null) {
				DrsObject obj = objectsMap.get(this.getObject1Ref());
				if (obj == null) {

					throw new TransformationException(
							"The property \""
									+ this.getAdjective()
									+ "\" does not reference to a valid primary object!");
				} else {
					this.setObject1(obj);
				}
			}

			if (this.getObject2() == null) {
				DrsObject obj = objectsMap.get(this.getObject2Ref());
				if (obj == null) {
					throw new TransformationException(
							"The property \""
									+ this.getAdjective()
									+ "\" does not reference to a valid secondary object!");
				} else {
					this.setObject2(obj);
				}
			}

			if (this.getObject3() == null) {
				DrsObject obj = objectsMap.get(this.getObject3Ref());
				if (obj == null) {
					throw new TransformationException(
							"The property \""
									+ this.getAdjective()
									+ "\" does not reference to a valid tertiary object!");
				} else {
					this.setObject3(obj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.BinaryProperty#toRuleMLElement(org.dom4j.Element,
	 * org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement)
			throws UnsupportedOperationException {
//		this.getObject1().toRuleMLElement(atom);
		this.getObject2().toRuleMLElement(atom);
		this.getObject3().toRuleMLElement(atom);
	}

}
