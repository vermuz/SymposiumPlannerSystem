package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.Map;

import org.dom4j.Element;

/**
 * Instances of this class represent membership statements of DRS in the form of
 * "has_part" atoms.
 * 
 * @author paba
 * 
 */

public class DrsGroupMembership extends DrsAtom {

	private final String groupRef;

	private final String memberRef;

	private DrsObject groupObject;

	private DrsObject memeberObject;

	public DrsObject getGroupObject() {
		return groupObject;
	}

	public void setGroupObject(DrsObject groupObject) {
		this.groupObject = groupObject;
	}

	public DrsObject getMemeberObject() {
		return memeberObject;
	}

	public void setMemeberObject(DrsObject memeberObject) {
		this.memeberObject = memeberObject;
	}

	public DrsGroupMembership(String groupRef, String memberRef) {
		if (groupRef == null) {
			throw new IllegalArgumentException(
					"The groupRef argument must not be null!");
		}
		if (memberRef == null) {
			throw new IllegalArgumentException(
					"The memberRef argument must not be null!");
		}
		this.groupRef = groupRef;
		this.memberRef = memberRef;
		this.groupObject = null;
		this.memeberObject = null;
	}

	/**
	 * This method parses a group membership statement from an XML element which
	 * is supposed to be a "has_part" element from a DRS XML document into a
	 * {@link DrsGroupMembership} object.
	 * 
	 * @param has_partEl
	 *            the "has_part" XML element.
	 * @return the group membership statement obtained from the given XML
	 *         element.
	 */

	public static DrsGroupMembership parseFromXmlElement(Element has_partEl) {
		String group = has_partEl.attributeValue("group");
		String member = has_partEl.attributeValue("member");
		return new DrsGroupMembership(group, member);
	}

	/**
	 * This method provides the reference to the group object this group
	 * membership statement is about.
	 * 
	 * @return the reference to the group object.
	 */

	public String getGroupRef() {
		return groupRef;
	}

	/**
	 * This method provides the reference to the object which this group
	 * membership asserts the membership of.
	 * 
	 * @return the reference to the member object.
	 */

	public String getMemberRef() {
		return memberRef;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject group = objectsMap.get(this.getGroupRef());
		if (group == null) {
			objectsMap.put(this.getGroupRef(),
					DrsObject.fromString(this.getGroupRef()));
		}

		DrsObject member = objectsMap.get(this.getMemberRef());
		if (member == null) {
			objectsMap.put(this.getMemberRef(),
					DrsObject.fromString(this.getMemberRef()));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			DrsObject groupObject = objectsMap.get(this.getGroupRef());
			if (groupObject == null || !groupObject.isGroupObject()) {
				throw new TransformationException(
						"\"has_part\" statement does not refer to a valid group object!");
			}else this.setGroupObject(groupObject);
			
			DrsObject memberObject = objectsMap.get(this.getMemberRef());
			if (memberObject == null) {
				throw new TransformationException(
						"\"has_part\" statement does not refer to a valid member object!");
			}else this.setMemeberObject(memberObject);
			groupObject.addObject(memberObject);

		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
