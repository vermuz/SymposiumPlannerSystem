package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.Map;

import org.dom4j.Element;

/**
 * Instances of this class represent adverbs as identified by the APE web
 * service.
 * 
 * @author paba
 * 
 */
public class DrsAdverb extends DrsAtom {

	private final String predicateRef;

	/**
	 * This is the actual adverb.
	 */
	private final String adverb;

	/**
	 * This is the degree of this adverb.
	 */
	private final AdverbDegree degree;

	/**
	 * This is the predicate this modifier is modifying. This is supposed to be
	 * the predicate that is referenced by {@link #predicateRef}.
	 */

	protected DrsPredicate predicate;

	/**
	 * Constructs an adverb from all the ingredients.
	 * 
	 * @param predicateRef
	 *            the reference to the predicate this predicate is modifying (s.
	 *            {@link #getPredicateRef()}).
	 * @param adverb
	 *            the actual adverb
	 * @param degree
	 *            the degree of this adverb.
	 */

	public DrsAdverb(String predicateRef, String adverb, AdverbDegree degree) {
		this.predicateRef = predicateRef;
		this.adverb = adverb;
		this.degree = degree;
	}

	/**
	 * Used for cloning only!
	 * 
	 * @param predicateRef
	 * @param predicate
	 * @param adverb
	 * @param degree
	 */
	protected DrsAdverb(String predicateRef, DrsPredicate predicate,
			String adverb, AdverbDegree degree) {
		this.predicateRef = predicateRef;
		this.adverb = adverb;
		this.degree = degree;
	}

	DrsAdverb changePredicate(DrsPredicate predicate) {
		return new DrsAdverb(predicate.getReference(), predicate, this.adverb,
				this.degree);
	}

	/**
	 * This method parses a XML element which is supposed to be a "modifier_adv"
	 * element from a DRS XML document into a {@link DrsAdverb} object.
	 * 
	 * @param adverbEl
	 *            the "modifier_adv" XML element
	 * @return the adverb that was obtained from the given XML element
	 */

	public static DrsAtom parseFromXml(Element adverbEl) {
		String ref = adverbEl.attributeValue("ref");
		String adverb = adverbEl.attributeValue("adverb");
		AdverbDegree degree = AdverbDegree.fromString(adverbEl
				.attributeValue("degree"));

		return new DrsAdverb(ref, adverb, degree);
	}

	/**
	 * This method provides the actual adverb.
	 * 
	 * @return the actual adverb
	 */

	public String getAdverb() {
		return adverb;
	}

	/**
	 * This method provides the degree of this adverb.
	 * 
	 * @return the degree of this adverb.
	 */

	public AdverbDegree getDegree() {
		return degree;
	}

	/**
	 * This method provides a string that can be used when generating
	 * identifiers for predicates that should be used in a RuleML document.
	 * 
	 * @return the identifier for this adverb.
	 */

	public String toRuleMLIdentifier() {
		if (this.degree == AdverbDegree.pos) {
			return adverb;
		} else if (this.degree == AdverbDegree.comp) {
			return "more_" + adverb;
		} else if (this.degree == AdverbDegree.sup) {
			return "most_" + adverb;
		} else {
			throw new RuntimeException("Enum constant \"" + this.degree
					+ "\" is not supported!");
		}
	}

	/**
	 * This method provides the predicate this modifier is modifying. This is
	 * supposed to be the predicate that is referenced by the value of
	 * {@link #getPredicateRef()}.
	 * 
	 * @see #getPredicateRef()
	 * @see #setPredicate(DrsPredicate)
	 * 
	 * @return the predicate this modifier is modifying
	 */

	public DrsPredicate getPredicate() {
		return predicate;
	}

	/**
	 * This method sets the predicate this modifier is modifying. This is
	 * supposed to be the predicate that is referenced by the value of
	 * {@link #getPredicateRef()}.
	 * 
	 * @see #getPredicateRef()
	 * @see #getPredicate()
	 * 
	 * @param predicate
	 *            the predicate this modifier is supposed to be modifying
	 * 
	 * @throws IllegalStateException
	 *             if the predicate is already set.
	 * @throws IllegalArgumentException
	 *             if the <code>predicate</code> parameter is <code>null</code>.
	 * 
	 */

	public void setPredicate(DrsPredicate predicate)
			throws IllegalStateException, IllegalArgumentException {
		if (this.predicate != null) {
			throw new IllegalStateException("The predicate is already set!");
		}
		if (predicate == null) {
			throw new IllegalArgumentException(
					"The predicate must not be set to null!");
		}
		this.predicate = predicate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		DrsPredicate pred = predicatesMap.get(this.getPredicateRef());
		if (pred == null) {
			try {
				throw new TransformationException("The adverb \""
						+ this.getAdverb()
						+ "\" does not reference to a valid predicate!");
			} catch (TransformationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			this.setPredicate(pred);
			pred.addAdverb(this);
		}
	}

	public String getPredicateRef() {
		return predicateRef;
	}

}
