package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.List;
import java.util.Map;

import org.dom4j.Element;

public class IntransitivePredicate extends DrsPredicate {

	/**
	 * Construct a predicate from all the ingredients available from the DRS.
	 * 
	 * @param reference
	 *            the reference to this predicate (s. {@link #getReference()}).
	 * @param verb
	 *            the predicate's verb (s. {@link #getVerb()}).
	 * @param subjectReference
	 *            the reference to the predicate's subject (s.
	 *            {@link #getSubjectRef()}).
	 */

	public IntransitivePredicate(String reference, String verb,
			String subjectReference) {
		super(reference, verb, subjectReference);
	}

	/**
	 * Used for cloning only!
	 * 
	 * @param reference
	 * @param adverbs
	 * @param prepositionalPhrases
	 * @param verb
	 * @param subjectReference
	 * @param subject
	 * @throws IllegalArgumentException
	 */

	protected IntransitivePredicate(String reference, List<DrsAdverb> adverbs,
			List<DrsPrepositionalPhrase> prepositionalPhrases, String verb,
			String subjectReference, DrsObject subject)
			throws IllegalArgumentException {
		super(reference, adverbs, prepositionalPhrases, verb, subjectReference,
				subject);
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsPredicate changeSubject(DrsObject subject) {
		return new IntransitivePredicate(this.reference, this.adverbs,
				this.prepositionalPhrases, this.verb, subject.getReference(),
				subject);
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsPredicate changePrepositionalPhrases(
			List<DrsPrepositionalPhrase> propostionalPhrases) {
		return new IntransitivePredicate(this.reference, this.adverbs,
				prepositionalPhrases, this.verb, this.subjectReference,
				this.subject);
	}


	/* (non-Javadoc)
	 * @see ils.ace2rrml.drs.DrsElement#resolveDrsPredicate(java.util.Map, java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			if (this.getSubject() == null) {
				DrsObject subj = (DrsObject) objectsMap.get(this
						.getSubjectRef());
				if (subj == null) {
					throw new TransformationException("The predicate \""
							+ this.getVerb()
							+ "\" is not referencing to a valid subject!");

				} else {
					this.setSubject(subj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see ils.ace2rrml.drs.DrsElement#toRuleMLElement(org.dom4j.Element,
	 * org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement) {
		this.getSubject().toRuleMLElement(atom);
		if (this.getPrepositionalPhrases().size() == 1) {
			this.getPrepositionalPhrases().get(0).getObject()
					.toRuleMLElement(atom);
		}
	}

}
