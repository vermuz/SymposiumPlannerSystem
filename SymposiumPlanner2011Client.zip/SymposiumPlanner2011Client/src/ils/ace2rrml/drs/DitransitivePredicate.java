package ils.ace2rrml.drs;

import ils.ace2rrml.TransformationException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;

public class DitransitivePredicate extends TransitivePredicate {
	protected final String indObjectReference;
	protected DrsObject indObject;

	/**
	 * Construct a predicate from all the ingredients.
	 * 
	 * @param reference
	 *            the reference to this predicate (s. {@link #getReference()}).
	 * @param verb
	 *            the predicate's verb (s. {@link #getVerb()}).
	 * 
	 * @param subjectReference
	 *            the reference to the predicate's subject (s.
	 *            {@link #getSubjectRef()}).
	 * @param objectRef
	 *            the reference to the object of this predicate.
	 * @param indObjectRef
	 *            the reference to the indirect object of this predicate.
	 */

	public DitransitivePredicate(String reference, String verb,
			String subjectReference, String objectRef, String indObjectRef)
			throws IllegalArgumentException {
		super(reference, verb, subjectReference, objectRef);

		if (indObjectRef == null) {
			throw new IllegalArgumentException(
					"A DRS predicate's indirect object reference must not be null");
		}
		this.indObjectReference = indObjectRef;

		this.indObject = null;
	}

	/**
	 * Used for cloning only!
	 * 
	 * @param reference
	 * @param adverbs
	 * @param prepositionalPhrases
	 * @param verb
	 * @param subjectReference
	 * @param subject
	 * @param objectReference
	 * @param object
	 * @param indObjectReference
	 * @param indObject
	 * @throws IllegalArgumentException
	 */

	protected DitransitivePredicate(String reference, List<DrsAdverb> adverbs,
			List<DrsPrepositionalPhrase> prepositionalPhrases, String verb,
			String subjectReference, DrsObject subject, String objectReference,
			DrsObject object, String indObjectReference, DrsObject indObject)
			throws IllegalArgumentException {
		super(reference, adverbs, prepositionalPhrases, verb, subjectReference,
				subject, objectReference, object);
		this.indObjectReference = indObjectReference;
		this.indObject = indObject;
	}

	public DrsObject getIndirectObject() {
		return this.indObject;
	}

	/**
	 * This method provides reference to the indirect object of this predicate.
	 * 
	 * @see #getIndirectObject()
	 * @see #setIndirectObject(DrsObject)
	 * 
	 * @return the reference to the predidate's indirect object.
	 */
	@Override
	public String getIndirectObjectRef() {
		return this.indObjectReference;
	}

	public void setIndirectObject(DrsObject indObject)
			throws IllegalStateException, IllegalArgumentException {
		if (this.indObject != null) {
			throw new IllegalStateException(
					"The indirect object is already set!");
		}
		if (indObject == null) {
			throw new IllegalArgumentException(
					"The indirect object must not be set to null!");
		}
		this.indObject = indObject;
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsPredicate changeSubject(DrsObject subject) {
		return new DitransitivePredicate(this.reference, this.adverbs,
				this.prepositionalPhrases, this.verb, subject.getReference(),
				subject, this.objectReference, this.object,
				this.indObjectReference, this.indObject);
	}

	/**
	 * {@inheritDoc}
	 */

	@Override
	protected DrsPredicate changeObject(DrsObject object)
			throws UnsupportedOperationException {
		return new DitransitivePredicate(this.reference, this.adverbs,
				this.prepositionalPhrases, this.verb, this.subjectReference,
				this.subject, object.getReference(), object,
				this.indObjectReference, this.indObject);
	}

	protected DrsPredicate changeIndirectObject(DrsObject indObject)
			throws UnsupportedOperationException {
		return new DitransitivePredicate(this.reference, this.adverbs,
				this.prepositionalPhrases, this.verb, this.subjectReference,
				this.subject, this.objectReference, this.object,
				indObject.getReference(), indObject);
	}

	@Override
	protected DrsPredicate changePrepositionalPhrases(
			List<DrsPrepositionalPhrase> propostionalPhrases) {
		return new DitransitivePredicate(this.reference, this.adverbs,
				prepositionalPhrases, this.verb, this.subjectReference,
				this.subject, this.objectReference, this.object,
				this.indObjectReference, this.indObject);
	}

	public List<DrsPredicate> splitOnIndirectObject()
			throws UnsupportedOperationException {
		DrsObject indObj = this.getIndirectObject();
		if (indObj.isGroupObject()) {
			List<DrsObject> members = indObj.getObjects();
			List<DrsPredicate> copies = new ArrayList<DrsPredicate>(
					members.size());
			for (DrsObject member : members) {
				copies.add(this.changeIndirectObject(member));
			}
			return copies;
		} else {
			List<DrsPredicate> id = new ArrayList<DrsPredicate>(1);
			id.add(this);
			return id;
		}
	}

	public List<DrsPredicate> splitOnDrsObject() {
		List<DrsPredicate> predicates = new ArrayList();
		List<DrsPredicate> ps1 = this.splitOnSubject();
		for (DrsPredicate p1 : ps1) {
			List<DrsPredicate> ps2 = ((TransitivePredicate) p1).splitOnObject();
			for (DrsPredicate p2 : ps2) {
				List<DrsPredicate> ps3 = ((DitransitivePredicate) p2)
						.splitOnIndirectObject();
				predicates.addAll(ps3);
			}
		}
		return predicates;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * ils.ace2rrml.drs.TransitivePredicate#addImplicitObject(java.util.Map)
	 */
	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject subj = objectsMap.get(this.getSubjectRef());
		if (subj == null)
			objectsMap.put(this.getSubjectRef(),
					DrsObject.fromString(this.getSubjectRef()));
		else
			this.setSubject(subj);

		DrsObject obj = objectsMap.get(this.getObjectRef());
		if (obj == null)
			objectsMap.put(this.getObjectRef(),
					DrsObject.fromString(this.getObjectRef()));
		else
			this.setObject(obj);

		DrsObject inobj = objectsMap.get(this.getIndirectObjectRef());
		if (inobj == null)
			objectsMap.put(this.getIndirectObjectRef(),
					DrsObject.fromString(this.getIndirectObjectRef()));
		else
			this.setIndirectObject(inobj);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * ils.ace2rrml.drs.TransitivePredicate#resolveDrsPredicate(java.util.Map,
	 * java.util.Map)
	 */
	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
		try {
			if (this.getSubject() == null) {
				DrsObject subj = objectsMap.get(this.getSubjectRef());
				if (subj == null) {
					throw new TransformationException("The predicate \""
							+ this.getVerb()
							+ "\" is not referencing to a valid subject!");

				} else {
					this.setSubject(subj);
				}
			}

			if (this.getObject() == null) {
				DrsObject obj = objectsMap.get(this.getObjectRef());
				if (obj == null) {
					throw new TransformationException("The predicate \""
							+ this.getVerb()
							+ "\" is not referencing to a valid direct object!");
				} else {
					this.setObject(obj);
				}
			}

			if (this.getIndirectObject() == null) {
				DrsObject indobj = objectsMap.get(this.getIndirectObjectRef());
				if (indobj == null) {
					throw new TransformationException(
							"The predicate \""
									+ this.getVerb()
									+ "\" is not referencing to a valid indirect object!");
				} else {
					this.setIndirectObject(indobj);
				}
			}
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * ils.ace2rrml.drs.TransitivePredicate#toRuleMLElement(org.dom4j.Element,
	 * org.dom4j.Element)
	 */
	public void toRuleMLElement(Element atom, Element contentElement) {
		if (this.getVerb().equals("be") && this.getObject().isCopula()&& this.getIndirectObject().isCopula()) {
			atom.element("Rel").setText(this.getSubject().getName());
			for (DrsProperty prop : this.getObject().getProperties()) {
				atom.addElement("Ind").setText(prop.getAdjective());
			}
			for (DrsProperty prop : this.getIndirectObject().getProperties()) {
				atom.addElement("Ind").setText(prop.getAdjective());
			}
		} else {
			this.getSubject().toRuleMLElement(atom);
			this.getObject().toRuleMLElement(atom);
			this.getIndirectObject().toRuleMLElement(atom);
			if (this.getPrepositionalPhrases().size() == 1) {
				this.getPrepositionalPhrases().get(0).getObject()
						.toRuleMLElement(atom);
			}
		}
	}
}
