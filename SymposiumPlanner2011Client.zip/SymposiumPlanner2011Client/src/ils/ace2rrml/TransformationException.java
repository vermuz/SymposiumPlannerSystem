package ils.ace2rrml;

/**
 * This exception is used by the {@link Ace2Rrml} class to indicate
 * implementation errors or unexpected behaviour of the APE web service.
 * 
 * @author paba
 * 
 */

public class TransformationException extends Exception {
    public static final long serialVersionUID = 0;

    /**
     * Constructs a {@link TransformationException} with a particular message.
     * 
     * @param message
     *            the exception's message.
     */
    public TransformationException(String message) {
        super(message);
    }
}
