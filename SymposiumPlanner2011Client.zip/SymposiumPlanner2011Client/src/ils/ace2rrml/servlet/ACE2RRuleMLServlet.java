package ils.ace2rrml.servlet;

import ils.ace2rrml.ACE2ReactionRuleML;
import ils.ace2rrml.ApeMessage;
import ils.ace2rrml.TransformationException;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ACE2RRuleMLServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ACE2RRuleMLServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		response.addHeader("pragma", "no-cache");
		response.addHeader("cache-control", "no-cache,must-revalidate");
		response.addHeader("expires", "0");
		PrintWriter out = response.getWriter();
		String oid = new String(request.getParameter("oid").getBytes(
				"iso-8859-1"), "GBK");
		String ace = new String(request.getParameter("ace").getBytes(
				"iso-8859-1"), "GBK");
		
		String ulexfile = new String(request.getParameter("ulexfile").getBytes(
		"iso-8859-1"), "GBK");

		try {
			Object resultObject = new ACE2ReactionRuleML().translate(oid, ace,ulexfile);
			if (resultObject instanceof ApeMessage[]) {
				ApeMessage[] messages = (ApeMessage[]) resultObject;
				out
						.println("<table  width=\"800\" border=\"1\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" class=\"resultMessages\">");
				out
						.println("<thead><tr><td width=\"40\" height=\"25\"><div align=\"center\"> &nbsp;</div></td>");
				out
						.println("<td width=\"65\" height=\"25\"><div align=\"center\">Type</div></td>");
				out
						.println("<td width=\"65\" height=\"25\"><div align=\"center\">Sentence</div></td>");
				out
						.println("<td width=\"342\" height=\"25\"><div align=\"center\">Problem</div></td>");
				out
						.println("<td width=\"673\" height=\"25\"><div align=\"center\">Suggestion</div></td>");
				out.println("</tr></thead><tbody>");
				for (int i = 0; i < messages.length; i++) {
					ApeMessage apeMessage = (ApeMessage) messages[i];
					if(apeMessage.getImportance().equalsIgnoreCase("error"))
					out
							.println("<tr><td height=\"25\"  class=\"error\"><strong>"
									+ apeMessage.getImportance()
									+ "</strong></td>");
					else
						out
						.println("<tr><td height=\"25\" bgcolor=\"#FFFF00\" class=\"error\"><strong>"
								+ apeMessage.getImportance()
								+ "</strong></td>");
					out.println("<td height=\"25\"><div align=\"center\">"
							+ apeMessage.getType() + "</div></td>");
					out.println("<td height=\"25\"><div align=\"center\">"
							+ apeMessage.getSentence() + "</div></td>");
					out.println("<td height=\"25\"><div align=\"center\">"
							+ apeMessage.getValue() + "</div></td>");
					out.println("<td height=\"25\"><div align=\"center\">"
							+ apeMessage.getRepair() + "</div></td>");
					out.println(" </tr>");
				}
				out.println("</tbody></table>");
			} else {
				String result = resultObject.toString();
//				result = result.replace("<", "&lt;");
//				result = result.replace(">", "&gt;");
				out.println(result);
			}
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
