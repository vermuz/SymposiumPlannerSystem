package ils.ace2rrml;

/**
 * This class provides constant static String fields that are supposed to be
 * possible values for the {@link ApeMessage#getType()} method.
 * 
 * See {@link ApeMessage#getType()} for an explanation why to favour String
 * constants over an enum.
 * 
 * @author paba
 * 
 */

public final class ApeMessageType {

    /**
     * Indicates a message concerning a certain character of the input text.
     */
    public static final String CHARACTER = "character";

    /**
     * Indicates a message concerning a certain word of the input text.
     */
    public static final String WORD = "word";

    /**
     * Indicates a message concerning a certain sentence of the input text.
     */
    public static final String SENTENCE = "sentence";

    /**
     * Indicates a message concerning the syntax of the input text.
     */
    public static final String SYNTAX = "syntax";

    /**
     * Indicates a message concerning an anaphor of the input text.
     */
    public static final String ANAPHOR = "anaphor";

    /**
     * Indicates a message that informs of a reached timelimit.
     */

    public static final String TIMELIMIT = "timelimit";

    /**
     * Indicates a message concerning the user defined lexicon.
     */
    public static final String LEXICON = "lexicon";

    /**
     * Indicates a message concerning the OWL output.
     */
    public static final String OWL = "owl";

    /**
     * Indicates a message concerning APE itself.
     */
    public static final String APE = "ape";

    /**
     * A private constructor to prevent this class from being instantiated.
     */
    private ApeMessageType() {
    }
}
