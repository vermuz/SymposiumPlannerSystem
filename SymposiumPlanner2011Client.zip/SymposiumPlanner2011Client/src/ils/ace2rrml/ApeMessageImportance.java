package ils.ace2rrml;

/**
 * This class provides constant static String fields that are supposed to be
 * possible values of the {@link ApeMessage#getImportance()} method.
 * 
 * See {@link ApeMessage#getImportance()} for an explanation why to favour
 * String constants over an enum.
 * 
 * @author paba
 * 
 */

public final class ApeMessageImportance {

    /**
     * Indicates a warning message.
     */
    public static final String WARNING = "warning";

    /**
     * Indicates an error message.
     */
    public static final String ERROR = "error";

    /**
     * Private constructor to prevent this class from being instantiated.
     */
    private ApeMessageImportance() {
    }
}
