package ils.ace2rrml;

import java.util.Map;

import ils.ace2rrml.drs.DrsAtom;
import ils.ace2rrml.drs.DrsObject;
import ils.ace2rrml.drs.DrsPredicate;

import org.dom4j.Element;

public class DrsQuery extends DrsAtom {

	private final String question;
	private final String objectRef;

	public static DrsAtom parseFromQueryXml(Element queryEl) {
		String objectRef = queryEl.attributeValue("obj");
		String question = queryEl.attributeValue("question");
		return new DrsQuery(objectRef, question);
	}

	private DrsQuery(String objectRef, String question) {
		this.objectRef = objectRef;
		this.question = question;
	}

	public void addImplicitObject(Map<String, DrsObject> objectsMap) {
		DrsObject obj = objectsMap.get(this.getObjReference());
		if (obj == null){
			obj = DrsObject.fromString(this.getObjReference());
			objectsMap.put(this.getObjReference(),obj);
		}
		obj.setQuery(true);
	}

	public void resolveDrsPredicate(Map<String, DrsObject> objectsMap,
			Map<String, DrsPredicate> predicatesMap) {
	}

	public String getQuestion() {
		return question;
	}


	public String getObjReference() {
		return objectRef;
	}
	
	

}
