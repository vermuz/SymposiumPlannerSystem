package ils.ace2rrml;

/**
 * Instances of this class represent results of an attempt to translate an ACE
 * text into an Reaction RuleML document.
 * 
 * @author paba
 * 
 */

public final class RrmlResult {

    /**
     * This field should indicate whether the rrml field contains a concise
     * representation of the input ACE text or only a literal translation of the
     * DRS.
     */

    private final boolean conciseRrml;

    /**
     * This field is supposed to contain the DRS representation string for the
     * ACE text that was issued to the APE web service.
     */

    private final String drs;

    /**
     * The actual Reaction RuleML document. This can be <code>null</code> iff
     * the {@link #apeMessages} array contains a message of importance (i.e. the
     * {@link ApeMessage#getImportance()} value) "error" or the {@link #error}
     * field is non-<code>null</code>.
     */
    private final String rrml;

    /**
     * Messages that were issued by the APE web service due to the malformedness
     * of the input ACE text. An empty array as well as value <code>null</code>
     * indicate that there are no messages.
     */

    private final ApeMessage[] apeMessages;

    /**
     * Contains a throwable that was thrown by the translation method. Thus, if
     * this field is non-<code>null</code> all other fields have no meaning
     * and should be <code>null</code>.
     * 
     * NOTE: This should be rather handled by the Axis2 framework, but there is
     * some bug that prevents this from working in the desired way. Hence this
     * workaround.
     */
    private final Throwable error;

    /**
     * Constructs an {@link RrmlResult} object with messages only.
     * 
     * @param apeMessages
     *            messages from the APE web service (s. {@link #getApeMessages()}).
     */
    public RrmlResult(ApeMessage[] apeMessages) {
        this(null, false, null, apeMessages);
    }

    /**
     * Constructs an {@link RrmlResult} object with an error.
     * 
     * @param error
     *            a throwable that was thrown during the attempt to translate
     *            the input ACE text or <code>null</code> if none was thrown
     *            (s. {@link #getErrorMessage()}, {@link #getErrorName()}).
     */
    public RrmlResult(Throwable error) {
        this(null, false, null, null, error);
    }

    /**
     * Constructs a {@link RrmlResult} with no error.
     * 
     * @param conciseRrml
     *            true iff the rrml argument is a concise translation (instead
     *            of a literal translation) from the DRS of the APE web service
     *            (s. {@link #isConciseRrml()}).
     * @param drs
     *            the DRS of the input ACE text (s. {@link #getDrs()}).
     * @param rrml
     *            the resulting Reaction RuleML document (s. {@link #getRrml()}).
     * @param apeMessages
     *            messages from the APE web service (s. {@link #getApeMessages()}).
     */

    public RrmlResult(String rrml, boolean conciseRrml, String drs,
            ApeMessage[] apeMessages) {
        this(rrml, conciseRrml, drs, apeMessages, null);
    }

    /**
     * Constructs an {@link RrmlResult} object from all the ingredients.
     * 
     * @param conciseRrml
     *            true iff the rrml argument is a concise translation (instead
     *            of a literal translation) from the DRS of the APE web service
     *            (s. {@link #isConciseRrml()}).
     * @param drs
     *            the DRS of the input ACE text (s. {@link #getDrs()}).
     * @param rrml
     *            the resulting Reaction RuleML document (s. {@link #getRrml()}).
     * @param apeMessages
     *            messages from the APE web service (s. {@link #getApeMessages()}).
     * @param error
     *            a throwable that was thrown during the attempt to translate
     *            the input ACE text or <code>null</code> if none was thrown
     *            (s. {@link #getErrorMessage()}, {@link #getErrorName()}).
     */

    public RrmlResult(String rrml, boolean conciseRrml, String drs,
            ApeMessage[] apeMessages, Throwable error) {
        this.rrml = rrml;
        this.conciseRrml = conciseRrml;
        this.drs = drs;
        this.apeMessages = apeMessages;
        this.error = error;
    }

    /**
     * This method provides the actual Reaction RuleML document. This can be
     * <code>null</code> iff the {@link #getApeMessages()} value contains a
     * message of importance (i.e. the {@link ApeMessage#getImportance()} value)
     * "error" or the {@link #getErrorName()} value is non-<code>null</code>.
     */
    public String getRrml() {
        return rrml;
    }

    /**
     * This method provides an array of the messages that were issued by the APE
     * web service due to the malformedness of the input ACE text. An empty array
     * as well as value <code>null</code> indicate that there are no messages.
     */

    public ApeMessage[] getApeMessages() {
        return apeMessages;
    }

    /**
     * This method is supposed to provide the name of the error that occurred
     * during the attempt to translate the input ACE text or <code>null</code>
     * if the translation was successful (in the sense that no implementation
     * error occurred). This value is <code>null</code> iff
     * {@link #getErrorMessage()}'s value is <code>null</code>.
     * 
     * @return the error name or <code>null</code> if none occured.
     */

    public String getErrorName() {
        return error == null ? null : error.getClass().getCanonicalName();
    }

    /**
     * This method is supposed to provide the message text of the error that
     * occurred during the attempt to translate the input ACE text or
     * <code>null</code> if the translation was successful (in the sense that
     * no implementation error occurred). This value is <code>null</code> iff
     * {@link #getErrorName()}'s value is <code>null</code>.
     * 
     * @return the error name or <code>null</code> if none occured.
     */

    public String getErrorMessage() {
        return error == null ? null : error.getMessage();
    }

    /**
     * This method is supposed to provide the DRS representation string for the
     * ACE text that was issued to the APE web service.
     * 
     * @return the DRS string produced by the APE web service.
     */

    public String getDrs() {
        return drs;
    }

    /**
     * This method is supposed to provide a Boolean that indicates whether the
     * rrml field contains a concise representation of the input ACE text or
     * only a literal translation of the DRS.
     * 
     * @return true if {@link #getRrml()} is a concise translation.
     */

    public boolean isConciseRrml() {
        return conciseRrml;
    }
}
