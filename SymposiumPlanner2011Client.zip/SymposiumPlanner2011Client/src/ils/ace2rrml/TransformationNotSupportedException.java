package ils.ace2rrml;

/**
 * This exception is used to indicate that a particular kind of translation from
 * ACE into Reaction RuleML (e.g. the concise translation) is not supported.
 * 
 * @author paba
 * 
 */
public class TransformationNotSupportedException extends Exception {

    public static final long serialVersionUID = 0;

    /**
     * Constructs a {@link TransformationNotSupportedException} with a
     * particular message.
     * 
     * @param message
     *            the exception's message.
     */
    public TransformationNotSupportedException(String message) {
        super(message);
    }
}
