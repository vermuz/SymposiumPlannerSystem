package ils.ace2rrml;

import ils.ace2rrml.drs.DrsAdverb;
import ils.ace2rrml.drs.DrsAtom;
import ils.ace2rrml.drs.DrsGroupMembership;
import ils.ace2rrml.drs.DrsObject;
import ils.ace2rrml.drs.DrsPredicate;
import ils.ace2rrml.drs.DrsPrepositionalPhrase;
import ils.ace2rrml.drs.DrsProperty;
import ils.ace2rrml.drs.DrsRelationShip;
import ils.ace2rrml.util.ProjectUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import nu.xom.Builder;
import nu.xom.ParsingException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

public class ACE2ReactionRuleML {

	// Base address for the APE REST-web service.
	public final static String QUERYBASE = "http://attempto.ifi.uzh.ch/ws/ape/apews.perl?";

	// XML namespace for Reaction RuleML
	public final static String XSI_NS = "http://www.w3.org/2001/XMLSchema-instance";

	public final static String RRML_NS = "http://www.ruleml.org/0.91/xsd";

	public final static String SCHEMA_INSTANCE = "http://www.ruleml.org/0.91/xsd http://ibis.in.tum.de/research/ ReactionRuleML/0.2/rr.xsd";

	Map<String, DrsObject> objectsMap = new HashMap<String, DrsObject>();

	private ApeMessage[] parseMessages(Element messagesEl) {
		List messageEls = messagesEl.elements("message");
		ApeMessage[] messages = new ApeMessage[messageEls.size()];
		for (int i = 0; i < messageEls.size(); i++) {
			messages[i] = ApeMessage
					.fromXmlElement((Element) messageEls.get(i));
		}
		return messages;
	}


	public Object translate(String oid,String ace, String ulexfile)
			throws TransformationException, IllegalArgumentException {
		if (ace == null || ace.length() == 0) {
			throw new IllegalArgumentException("No input");
		}
		String queryString;
		try {
			String params = "&cdrsxml=on";
			if (!ulexfile.trim().equals("")) {
				params = params + "&ulexfile=" + ulexfile;
			}
			queryString = QUERYBASE + "text=" + URLEncoder.encode(ace, "UTF-8")
					+ params;
		} catch (UnsupportedEncodingException uee) {
			throw new TransformationException("Unsupported encoding" + ": "
					+ uee.getMessage());
		}
		// query the APE web service
		nu.xom.Document doc1 = null;
		Builder builder = new Builder();
		try {
			doc1 = builder.build(queryString);
		} catch (ParsingException ex) {
			throw new TransformationException(
					"Malformed XML from web service: " + ex.getMessage());
		} catch (IOException ex) {
			throw new TransformationException(
					"Unable to connect to web service: " + ex.getMessage());
		}
		String temp = doc1.toXML();
		temp = temp.replaceAll("&lt;", "<");
		temp = temp.replaceAll("<&gt;", "()");
		temp = temp.replaceAll("&gt;", ">");
		temp = temp.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");

		Document doc = null;
		try {
			doc = DocumentHelper.parseText(temp);
		} catch (DocumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Element apeResult = doc.getRootElement();

		// check for error first

		Element errorEl = apeResult.element("error");
		if (errorEl != null) {
			return "An error occurred while parsing the ACE query: "
					+ errorEl.getText();
		}

		Element messagesEl = apeResult.element("messages");
		ApeMessage[] messages = null;
		if (messagesEl == null) {
			messages = new ApeMessage[0];
		} else {
			messages = parseMessages(messagesEl);
		}
		// check if one of the messages is an error

		for (ApeMessage msg : messages) {
			if (msg.getImportance().equals("error"))
				return messages;
		}

		Element drsElement = (Element) doc.selectSingleNode("//DRS");

		Document rrmlDoc = DocumentHelper.createDocument();
		Element root = rrmlDoc.addElement("RuleML", RRML_NS);
		root.addAttribute("xsi:schemaLocation", SCHEMA_INSTANCE);
		root.addAttribute("xmlns:xsi", XSI_NS);

		Element oidEl = root.addElement("oid", RRML_NS);
		Element oidInd = oidEl.addElement("Ind", RRML_NS);
		oidInd.setText("Generated message from ACE text \"" + ace + "\".");

		Element msgEl = root.addElement("Message", RRML_NS);
		msgEl.addAttribute("mode", "outbound");
		msgEl.addAttribute("directive", "query-sync");

		Element msgOidEl = msgEl.addElement("oid", RRML_NS);
		Element msgOidInd = msgOidEl.addElement("Ind", RRML_NS);
		msgOidInd.setText(oid);

		Element protocolEl = msgEl.addElement("protocol", RRML_NS);
		Element protocolInd = protocolEl.addElement("Ind", RRML_NS);
		protocolInd.setText("esb");

		Element senderEl = msgEl.addElement("sender", RRML_NS);
		Element senderInd = senderEl.addElement("Ind", RRML_NS);
		senderInd.setText("User");

		Element contentEl = msgEl.addElement("content", RRML_NS);

		// Element rulebaseEl = contentEl.addElement("Rulebase",RRML_NS);

		try {
			translateAtom(drsElement, contentEl, false);
		} catch (TransformationNotSupportedException e) {
			System.out.println("Translate Atom not possible: "
					+ e.getMessage());
		}

        return ProjectUtil.doc2String(rrmlDoc);
	}
	


	private void translateAtom(Element topDrsElement, Element element,
			boolean tag) throws TransformationException,
			TransformationNotSupportedException {

		List<Element> elements = topDrsElement.elements();
		Map<String, DrsPredicate> predicatesMap = new HashMap<String, DrsPredicate>();
		List<DrsAtom> drsAtoms = new LinkedList<DrsAtom>();

		// resolve the explicit objects at first
		for (Object object : topDrsElement.elements("object")) {
			Element objectElement = (Element) object;
			DrsObject obj = DrsObject.parseFromObjectXml(objectElement);
			drsAtoms.add(obj);
			objectsMap.put(obj.getReference(), obj);
		}

		Element contentElement = null;
		if (!tag) {// first layer of DRS
			if (topDrsElement.elements().size() == 1
					&& topDrsElement.element("Question") != null)
				contentElement = element;
			else
				contentElement = element.addElement("Assert");
		} else
			contentElement = element;

		for (Element drsElement : elements) {
			String name = drsElement.getName();
			if (name.equals("object")) {
				continue;
			} else if (name.equals("query")) {
				drsAtoms.add(DrsQuery.parseFromQueryXml(drsElement));
			} else if (name.equals("predicate")) {
				DrsAtom predicate = DrsPredicate.parseFromXml(drsElement);
				drsAtoms.add(predicate);
				predicatesMap.put(((DrsPredicate) predicate).getReference(),
						(DrsPredicate) predicate);
			} else if (name.equals("modifier_adv")) {
				drsAtoms.add(DrsAdverb.parseFromXml(drsElement));
			} else if (name.equals("modifier_pp")) {
				drsAtoms.add(DrsPrepositionalPhrase.parseFromXml(drsElement));
			} else if (name.equals("property")) {
				drsAtoms.add(DrsProperty.parseFromXml(drsElement));
			} else if (name.equals("has_part")) {
				drsAtoms.add(DrsGroupMembership.parseFromXmlElement(drsElement));
			} else if (name.equals("relation")) {
				drsAtoms.add(DrsRelationShip.parseFromXmlElement(drsElement));
			} else if (name.equals("Question")) {
//				Element contentElementNew = contentElement.addElement("Query");
				translateAtom(drsElement.element("DRS"),
						contentElement, true);
			} else if (name.equals("Implication")) {
				List drsList = drsElement.elements("DRS");
				Element ruleElement = contentElement.addElement("Rule");
				Element ifElement = ruleElement.addElement("if");
				translateAtom((Element) drsList.get(0), ifElement, true);
				Element thenElement = ruleElement.addElement("then");
				translateAtom((Element) drsList.get(1), thenElement, true);
			} else if (name.equals("Negation")) {
				Element subAssertElement = contentElement.addElement("Neg");
				translateAtom(drsElement.element("DRS"), subAssertElement,
						true);
			} else if (name.equals("NAF")) {
				Element subAssertElement = contentElement.addElement("Naf");
				translateAtom(drsElement.element("DRS"), subAssertElement,
						true);
			} else if (name.equals("Disjunction")) {
				List<Element> drsList = drsElement.elements("DRS");
				Element subAssertElement = contentElement
						.addElement("Disjunction");
				for (Element drsEle : drsList) {
					translateAtom(drsEle, subAssertElement, true);
				}

			} else {
				throw new TransformationNotSupportedException("DRS element \""
						+ name + "\" is not supported!");
			}
		}

		// add the implicit objects
		for (DrsAtom drsElement : drsAtoms) {
			drsElement.addImplicitObject(objectsMap);
		}

		// resolve the references
		for (DrsAtom drsElement : drsAtoms) {
			drsElement.resolveDrsPredicate(objectsMap, predicatesMap);
		}

		// now start the actual generation of RuleML code
		// here all generated RuleML atoms are accumulated
		for (DrsAtom drsAtom : drsAtoms) {
			if (drsAtom instanceof DrsPredicate)
				generationDrsPredicate(drsAtom, contentElement);
		}

	}

	private void generationDrsPredicate(DrsAtom drsElement,
			Element contentElement) throws TransformationNotSupportedException {
		DrsPredicate pred = (DrsPredicate) drsElement;
		if (!pred.getSubject().isQuery()) {
			List<DrsPredicate> predicates = new ArrayList();
			predicates.addAll(pred.splitOnDrsObject());

			for (DrsPredicate subPpred : predicates) {
				if (subPpred.getPrepositionalPhrases().size() > 2
						|| subPpred.getAdverbs().size() > 2) {
					// more than one prepositional phrase or more that one
					// adverb is
					// not supported
					throw new TransformationNotSupportedException(
							"Predicates having more than one adverb or more than 2 prepositional phrase are not supported!");
				} else {
					Element atom = contentElement.addElement("Atom");
					atom.addElement("Rel").setText(
							subPpred.toRuleMLIdentifier());
					subPpred.toRuleMLElement(atom, contentElement);
				}

			}
		} else {
			if (pred.getPrepositionalPhrases().size() > 2
					|| pred.getAdverbs().size() > 2) {
				// more than one prepositional phrase or more that one adverb is
				// not supported
				throw new TransformationNotSupportedException(
						"Predicates having more than one adverb or more than 2 prepositional phrase are not supported!");
			} else {
				Element atom = contentElement.addElement("Atom");
				atom.addElement("Rel").setText(pred.toRuleMLIdentifier());
				pred.toRuleMLElement(atom, contentElement);
			}
		}
	}

	public static void main(String[] args) {
		try {
			new ACE2ReactionRuleML()
					.translate(
							"HCLS",
							"Which full papers are accepted?",
//							"What is the interests and the name of Li in a slot?",							
//							"What is the interests and the name of Li?",
//							"What is the contactInformation of the general-chair-of-RuleML-2011-IJCAI?",
//							"What inserts the red card and an green apple?",
//							"What inserts Li's card and the paper of Li?",
//							"Who is Zhao and Li?",
//							"Who is an appler and a banana?",
//							"Li is higher than Zhao.",
//							"Li is high and tall.",
//							"A green apple is higher than a red paper.",
//							"Who is high and tall?",
//							"Li is more fond-of Zhao than Ming.",
//							"Who is taller than Li?",
//							"Who is LI?",
							"http://de.dbpedia.org/redirects/ruleml/ruleml2011.prog");
		} catch (TransformationException te) {
			System.err
					.println("An error occured while transforming the ACE query into a Reaction RuleML document: "
							+ te.getMessage());
		}
	}
}
