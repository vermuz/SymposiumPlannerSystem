package ils.ace2rrml.util;

import ils.ace2rrml.ACE2ReactionRuleML;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

public class ProjectUtil {
	 public static String getProjectDir() {
			String parentFile = ACE2ReactionRuleML.class.getResource("/").getFile()
					.toString();
			File serverDir = (new File(parentFile)).getParentFile().getParentFile();
			parentFile = serverDir.getAbsolutePath().replaceAll("%20", " ");
			return (new StringBuilder(String.valueOf(parentFile.replaceAll("%20",
					" ")))).append(File.separator).toString();
		}
	 
	 public static synchronized String doc2String(Document doc){
		 XMLWriter writer = null;
	        OutputFormat format = OutputFormat.createPrettyPrint();
	        format.setEncoding("GBK");
	        try
	        {
	            writer = new XMLWriter(new FileWriter(new File(getProjectDir()+"result.xml")), format);
	            writer.write(doc);
	            writer.close();
	        }
	        catch(IOException e)
	        {
	            e.printStackTrace();
	        }
	        FileReader fr = null;
	        try
	        {
	            fr = new FileReader((new StringBuilder(String.valueOf(getProjectDir()))).append("result.xml").toString());
	        }
	        catch(FileNotFoundException e)
	        {
	            e.printStackTrace();
	        }
	        BufferedReader br = new BufferedReader(fr);
	        String content = "";
	        try
	        {
	            while(br.ready()) 
	            {
	                content = (new StringBuilder(String.valueOf(content))).append(br.readLine()).toString();
	                content = (new StringBuilder(String.valueOf(content))).append("\n").toString();
	            }
	        }
	        catch(IOException e)
	        {
	            e.printStackTrace();
	        }
	        return content;
	 }
}
