package ils.ace2rrml;

import org.dom4j.Element;


/**
 * Instances of this class represent messages that were issued by the APE
 * web service upon an ACE input text.
 * 
 * @author paba
 * 
 */

public final class ApeMessage {

    /**
     * Indicates the importance of the message. See {@link ApeMessageImportance}
     * for a complete list of possible values.
     * 
     * NOTE: An enum would be preferable here instead of a String, yet, this
     * causes error in conjunction with the axis2 framework, as enums are not
     * properly translated into SOAP.
     */
    private final String importance;
    /**
     * Indicates the type of the message. See {@link ApeMessageType} for a
     * complete list of possible values.
     * 
     * NOTE: An enum would be preferable here instead of a String, yet, this
     * causes error in conjunction with the axis2 framework, as enums are not
     * properly translated into SOAP.
     */
    private final String type;

    /**
     * This string is supposed to be a natural number to identify the sentence
     * this message referring to.
     */
    private final String sentence;

    /**
     * This is the token this message is referring to.
     */
    private final String token;

    /**
     * This is the actual message text.
     */

    private final String value;

    /**
     * The suggestion how to correct the input ACE text.
     */
    private final String repair;

    /**
     * Constructs a message from all the ingredients we can get from the
     * corresponding "message" element in the APE result XML document.
     * 
     * @param importance
     *            the message's importance (s. {@link #getImportance()}).
     * @param type
     *            the message's type (s. {@link #getType()}).
     * @param sentence
     *            a reference to the concerned sentence (s.
     *            {@link #getSentence()}).
     * @param token
     *            the concerned token (s. {@link #getToken()}).
     * @param value
     *            the actual message text (s. {@link #getValue()}).
     * @param repair
     *            the suggestion to correct the resp. issue (s.
     *            {@link #getRepair()}).
     */

    public ApeMessage(String importance, String type, String sentence,
            String token, String value, String repair) {
        this.importance = importance;
        this.type = type;
        this.sentence = sentence;
        this.token = token;
        this.value = value;
        this.repair = repair;
    }

    /**
     * This method parses the given XML element which is supposed to be an
     * "message" element below the "messages" element in the APE result XML
     * document to an {@link ApeMessage} object.
     * 
     * @param messageEl
     *            the XML element representing a message
     * @return the {@link ApeMessage} representation of the given message
     */

    public static ApeMessage fromXmlElement(Element messageEl) {
        String importance = messageEl.attributeValue("importance");
        String type = messageEl.attributeValue("type");
        String sentence = messageEl.attributeValue("sentence");
        String token = messageEl.attributeValue("token");
        String value = messageEl.attributeValue("value");
        String repair = messageEl.attributeValue("repair");
        return new ApeMessage(importance, type, sentence, token, value, repair);
    }

    /**
     * This method provides the importance of the message. See
     * {@link ApeMessageImportance} for a complete list of possible values.
     * 
     * NOTE: An enum would be preferable here instead of a String, yet, this
     * causes error in conjunction with the axis2 framework, as enums are not
     * properly translated into SOAP.
     * 
     * @return the message's importance.
     */
    public String getImportance() {
        return importance;
    }

    /**
     * This method provides the type of the message. See {@link ApeMessageType}
     * for a complete list of possible values.
     * 
     * NOTE: An enum would be preferable here instead of a String, yet, this
     * causes error in conjunction with the axis2 framework, as enums are not
     * properly translated into SOAP.
     * 
     * @return the message's type.
     */
    public String getType() {
        return type;
    }

    /**
     * This method provides a string that is supposed to be a natural number to
     * identify the sentence this message referring to.
     * 
     * @return a reference to the concerned sentence.
     */

    public String getSentence() {
        return sentence;
    }

    /**
     * This method provides the token this message is referring to.
     * 
     * @return the concerned token.
     */

    public String getToken() {
        return token;
    }

    /**
     * This method provides the actual message text.
     * 
     * @return the message text.
     */

    public String getValue() {
        return value;
    }

    /**
     * This method provides the suggestion how to correct the input ACE text.
     * 
     * @return the correction suggestion.
     */

    public String getRepair() {
        return repair;
    }

}
