/**
 * 
 */
package ils.ace2rrml;

import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * @author Administrator
 *
 */
public class InterfaceNameDecision {
	private static String configFilePath = getProjectDir() + "conf" + File.separator
	+ "interfaces-keywords.xml";
	
	public String getInterfaceName(String objectName){
		try {
			Document doc = new SAXReader().read(new File(configFilePath));
			List<Element> list = doc.selectNodes("//keyword");
			
			for(int i=0;i<list.size();i++){
				Element ele = list.get(i);
				System.out.println("The name of the object in ACE text:"+objectName);
				if(objectName.toLowerCase().contains(ele.getText()))
					return ele.getParent().getParent().attributeValue("name");
			}
			
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "InterfaceNotDecided";
	}
	
	
	public static String getProjectDir() {
		String parentFile = ACE2ReactionRuleML.class.getResource("/").getFile()
				.toString();
		File serverDir = (new File(parentFile)).getParentFile().getParentFile();
		parentFile = serverDir.getAbsolutePath().replaceAll("%20", " ");
		return (new StringBuilder(String.valueOf(parentFile.replaceAll("%20",
				" ")))).append(File.separator).toString();
	}
	

}
