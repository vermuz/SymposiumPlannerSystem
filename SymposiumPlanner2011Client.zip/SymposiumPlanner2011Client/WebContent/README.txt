1. This client is implemented with Ajax+Servlet+JSP.
2. %TOMACT_HOME%/webapps/conf/prova-interfaces.xml describes all the query interfaces available in SPS 2011.
3. Before using this client, please make sure the MULE address at line 75 of rruleml.jsp. The default address is: http://localhost:8888.
4. Please make sure that the link of user lexicons needs to be accessed by the external APE engine.