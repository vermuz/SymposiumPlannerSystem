function elementSelected(){
 
		var choice = document.form1.select1.selectedIndex;
	    //IJCAI 2011 general chair contact
		var choice0 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_GeneralChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
	    //publicity chair sponsoring
		var choice1 = 
			      "<Atom>" + "\n         " +
			      "<Rel>sponsor</Rel>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>contact</Fun>" + "\n            " +
				"<Ind>Mark</Ind>" + "\n            " +
				"<Ind>JBoss</Ind>" + "\n         " +
				"</Expr>" + "\n         " + 
			    "<Ind type=\"integer\">500</Ind>" + "\n         " +
				"<Expr>" + "\n            " +
				"<Fun>results</Fun>" + "\n            " +
				"<Var>Level</Var>" + "\n            " +
				"<Var>Benefits</Var>" + "\n            " +
				"<Var>DeadlineResults</Var>" + "\n         " +
				"</Expr>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>performative</Fun>" + "\n            " +
				"<Var>Action</Var>" + "\n         " +
				"</Expr>" + "\n      " + 
			    "</Atom>" + "\n";
       //IJCAI2011 publicity chair contact
	   var choice2 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_PublicityChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n"; 
	    //liaison chair view media partners
		var choice3 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewMediaPartners</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Partner</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//liaison chair view organization partners
		var choice4 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewOrganizationPartners</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Partner</Var>" + "\n      " + 
				"</Atom>" + "\n";
		
		//liaison chair view sponsors with regards to level
		var choice5 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewSponsors</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Company</Var>" + "\n         " + 
				"<Var>SponsorLevel</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//liaison chair view sponsors
		var choice6 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewSponsors</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Company</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//IJCAI 2011 liaison chair contact
		var choice7 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_LiaisonChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
				  
		//IJCAI 2011 program chair contact
		var choice8 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_ProgramChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";

 //BRF 2011 general chair contact
		var choice9 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_GeneralChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
				  
  //BRF 2011 publicity chair contact
	   var choice10 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_PublicityChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n"; 
				  
				  //BRF 2011 liaison chair contact
		var choice11 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_LiaisonChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
				  
		//BRF 2011 program chair contact
		var choice12 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_ProgramChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
	 	//Program Chair Retrieve Tracks
		var choice13 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTracks</Rel>" + "\n\t\t" +
			"<Var>Track</Var>" + "\n\t    " +
			"</Atom>";
			      
		var choice14 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTopicsOfATrack</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Rules and Norms</Ind>" + "\n\t\t" +
			"<Var>Topic</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve Track of a Topic
		var choice15 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTrackOfATopic</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">The relationship between rules and legal argumentation schemes</Ind>" + "\n\t\t" +
			"<Var>Track</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve all Track Chairs
		var choice16 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTrackChairs</Rel>" + "\n\t\t" +
			"<Var>TrackChairs</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve names of Chairs for specific Track
		var choice17 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getChairsOfTrack</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Rules and Norms</Ind>" + "\n\t\t" +
			"<Var>Chairs</Var>" + "\n\t    " +
			"</Atom>";
			
		 //Submission Query
     var choice18 = 
			      "<Atom>" + "\n         " +
			      "<Rel>submission</Rel>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>contact</Fun>" + "\n            " +
				"<Ind>Mark</Ind>" + "\n            " +
				"<Ind>JBoss</Ind>" + "\n         " +
				"<Ind>USA</Ind>" + "\n         " +
				"<Ind>markDOTjbossATgmailDOTcom</Ind>" + "\n         " +
				"</Expr>" + "\n         " + 
			  "<Ind type=\"string\">Rules and Automated Reasoning</Ind>" + "\n         " +
			  "<Ind type=\"string\">Full Paper</Ind>" + "\n         " +
				"<Ind type=\"string\">rules; reasoning</Ind>" + "\n         " +
			    "</Atom>" + "\n";

	  

				  
	 var messageHeader =
                  "<RuleML xmlns=\n   \"http://www.ruleml.org/0.91/xsd\"" + "\n" +
				  " xmlns:xsi=\n   \"http://www.w3.org/2001/XMLSchema-instance\"" + "\n" +
				  " xsi:schemaLocation=\n   \"http://www.ruleml.org/0.91/xsd" + "\n   " +
				  " http://ibis.in.tum.de/research/" + "\n    " + "ReactionRuleML/0.2/rr.xsd\"" + "\n" +
				  " xmlns:ruleml2011=" + "\n   " + "\"http://ibis.in.tum.de/projects/paw#\">" + "\n" +
				  "\n " + "<Message mode=\"outbound\"" + "\n  " + "directive=\"query-sync\">" +
			      "\n   " + "<oid>" + "\n      " + 
			      "<Ind>SymposiumPlannerSystem</Ind>" + "\n   " +
			      "</oid>" + "\n   " +
			      "<protocol>" + "\n      " +
			      "<Ind>esb</Ind>" + "\n   " +
			      "</protocol>" + "\n   " +
			      "<sender>" + "\n      " +
			      "<Ind>User</Ind>" + "\n   " +
			      "</sender>" + "\n   " +
			      "<content>" + "\n      ";					
		
	 var messageFooter = 			     
				"   " + "</content>" + "\n " +
			      "</Message>" + "\n" +
			      "</RuleML>";
		
 
		if(choice == 0){
			document.form2.box1.value = messageHeader + choice0 + messageFooter;
		}else if(choice == 1){
			document.form2.box1.value = messageHeader + choice1 + messageFooter;
		}else if(choice == 2){
			document.form2.box1.value = messageHeader + choice2 + messageFooter;
		}else if(choice == 3){
			document.form2.box1.value = messageHeader + choice3 + messageFooter;
		}else if(choice == 4){
			document.form2.box1.value = messageHeader + choice4 + messageFooter;
		}else if(choice == 5){
			document.form2.box1.value = messageHeader + choice5 + messageFooter;
		}else if(choice == 6){
			document.form2.box1.value = messageHeader + choice6 + messageFooter;
		}else if(choice == 7){
			document.form2.box1.value = messageHeader + choice7 + messageFooter;
		}else if(choice == 8){
			document.form2.box1.value = messageHeader + choice8 + messageFooter;
		}else if(choice == 9){
			document.form2.box1.value = messageHeader + choice9 + messageFooter;
		}else if(choice == 10){
			document.form2.box1.value = messageHeader + choice10 + messageFooter;
		}else if(choice == 11){
			document.form2.box1.value = messageHeader + choice11 + messageFooter;
		}else if(choice == 12){
			document.form2.box1.value = messageHeader + choice12 + messageFooter;
		}else if(choice == 13){
			document.form2.box1.value = messageHeader + choice13 + messageFooter;
		}else if(choice == 14){
			document.form2.box1.value = messageHeader + choice14 + messageFooter;
		}else if(choice == 15){
			document.form2.box1.value = messageHeader + choice15 + messageFooter;
		}else if(choice == 16){
			document.form2.box1.value = messageHeader + choice16 + messageFooter;
		}else if(choice == 17){
			document.form2.box1.value = messageHeader + choice17 + messageFooter;
		}else if(choice == 18){
			document.form2.box1.value = messageHeader + choice18 + messageFooter;
		}
	}
	
	function elementSelected3(){
 
		var choice = document.form3.select3.selectedIndex;
	    //IJCAI 2011 general chair contact
		var choice0 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_GeneralChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
	    //publicity chair sponsoring
		var choice1 = 
			      "<Atom>" + "\n         " +
			      "<Rel>sponsor</Rel>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>contact</Fun>" + "\n            " +
				"<Ind>Mark</Ind>" + "\n            " +
				"<Ind>JBoss</Ind>" + "\n         " +
				"</Expr>" + "\n         " + 
			    "<Ind type=\"integer\">500</Ind>" + "\n         " +
				"<Expr>" + "\n            " +
				"<Fun>results</Fun>" + "\n            " +
				"<Var>Level</Var>" + "\n            " +
				"<Var>Benefits</Var>" + "\n            " +
				"<Var>DeadlineResults</Var>" + "\n         " +
				"</Expr>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>performative</Fun>" + "\n            " +
				"<Var>Action</Var>" + "\n         " +
				"</Expr>" + "\n      " + 
			    "</Atom>" + "\n";
       //IJCAI2011 publicity chair contact
	   var choice2 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_PublicityChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n"; 
	    //liaison chair view media partners
		var choice3 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewMediaPartners</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Partner</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//liaison chair view organization partners
		var choice4 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewOrganizationPartners</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Partner</Var>" + "\n      " + 
				"</Atom>" + "\n";
		
		//liaison chair view sponsors with regards to level
		var choice5 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewSponsors</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Company</Var>" + "\n         " + 
				"<Var>SponsorLevel</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//liaison chair view sponsors
		var choice6 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewSponsors</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Company</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
				  
	    //BRF 2011 liaison chair contact
		var choice7 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_LiaisonChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
				  
		//BRF 2011 program chair contact
		var choice8 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATijcai_ProgramChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
	 	//Program Chair Retrieve Tracks
		var choice9 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTracks</Rel>" + "\n\t\t" +
			"<Var>Track</Var>" + "\n\t    " +
			"</Atom>";
			      
		var choice10 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTopicsOfATrack</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Rule Transformation and Extraction</Ind>" + "\n\t\t" +
			"<Var>Topic</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve Track of a Topic
		var choice11 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTrackOfATopic</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Extraction of rules from code</Ind>" + "\n\t\t" +
			"<Var>Track</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Find Tracks relevant to Keywords (string)
		var choice12 =
			"<Atom>" + "\n\t\t" +
			"<Rel>findTracks</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">defeasibility; rule exceptions</Ind>" + "\n\t\t" +
			"<Var>ScoredTrack</Var>" + "\n\t    " +
			"</Atom>";



	    //Program Chair Retrieve all Track Chairs
		var choice13 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTrackChairs</Rel>" + "\n\t\t" +
			"<Var>TrackChairs</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve names of Chairs for specific Track
		var choice14 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getChairsOfTrack</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Rule Transformation and Extraction</Ind>" + "\n\t\t" +
			"<Var>Chairs</Var>" + "\n\t    " +
			"</Atom>";
	//Program Chair Retrieve Important Dates
		var choice15 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getImportantDates</Rel>" + "\n\t\t" +
			"<Var>Title</Var>" + "\n\t\t" +
			"<Expr>" + "\n\t\t" +
			"  <Fun>dateTime</Fun>" + "\n\t\t" +
			"  <Var>StartYear</Var>" + "\n\t\t" +
			"  <Var>StartMonth</Var>" + "\n\t\t" +
			"  <Var>StartDay</Var>" + "\n\t\t" +
			"  <Var>StartHour</Var>" + "\n\t\t" +
			"  <Var>StartMinute</Var>" + "\n\t\t" +
			"</Expr>" + "\n\t\t" +
			"<Expr>" + "\n\t\t" +
			"  <Fun>dateTime</Fun>" + "\n\t\t" +
			"  <Var>EndYear</Var>" + "\n\t\t" +
			"  <Var>EndMonth</Var>" + "\n\t\t" +
			"  <Var>EndDay</Var>" + "\n\t\t" +
			"  <Var>EndHour</Var>" + "\n\t\t" +
			"  <Var>EndMinute</Var>" + "\n\t\t" +
			"</Expr>" + "\n\t   "+
			"</Atom>";
			
	 	//Program Chair Retrieve Important Dates
		var choice16 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getItemOfImportantDates</Rel>" + "\n\t\t" +
			"<Ind>RuleML-2011@IJCAI dates</Ind>" + "\n\t\t" +
			"<Expr>" + "\n\t\t" +
			"  <Fun>dateTime</Fun>" + "\n\t\t" +
			"  <Var>StartYear</Var>" + "\n\t\t" +
			"  <Var>StartMonth</Var>" + "\n\t\t" +
			"  <Var>StartDay</Var>" + "\n\t\t" +
			"  <Var>StartHour</Var>" + "\n\t\t" +
			"  <Var>StartMinute</Var>" + "\n\t\t" +
			"</Expr>" + "\n\t\t" +
			"<Expr>" + "\n\t\t" +
			"  <Fun>dateTime</Fun>" + "\n\t\t" +
			"  <Var>EndYear</Var>" + "\n\t\t" +
			"  <Var>EndMonth</Var>" + "\n\t\t" +
			"  <Var>EndDay</Var>" + "\n\t\t" +
			"  <Var>EndHour</Var>" + "\n\t\t" +
			"  <Var>EndMinute</Var>" + "\n\t\t" +
			"</Expr>" + "\n\t   "+
			"</Atom>";
			//Program Chair Retrieve Important Dates
		var choice17 =
				"<Atom>" + "\n\t\t" +
			"<Rel>getTrackPapers</Rel>" + "\n\t\t" +
			  "<Ind>accepted</Ind>" + "\n\t\t" +
			"<Var>TrackPapers</Var>" + "\n\t    " +
			
			"</Atom>";
		var choice18 =
				"<Atom>" + "\n\t\t" +
			"<Rel>getFullPapers</Rel>" + "\n\t\t" +
                        "<Ind>accepted</Ind>" + "\n\t\t" +
			"<Var>FullPapers</Var>" + "\n\t    " +
			"</Atom>";	
		var choice19 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getAuthorsOfPaper</Rel>" + "\n\t\t" +
			"<Ind>'Rule-based Distributed and Agent Systems'</Ind>" + "\n\t\t" +
			"<Var>Authors</Var>" + "\n\t    " +
			"</Atom>";
			var choice20 =
				"<Atom>" + "\n\t\t" +
			"<Rel>getShortPapers</Rel>" + "\n\t\t" +
                        "<Ind>accepted</Ind>" + "\n\t\t" +
			"<Var>ShortPapers</Var>" + "\n\t    " +
			"</Atom>";	
			var choice21 =
				"<Atom>" + "\n\t\t" +
			"<Rel>getPosterPapers</Rel>" + "\n\t\t" +
                        "<Ind>accepted</Ind>" + "\n\t\t" +
			"<Var>PosterPapers</Var>" + "\n\t    " +
			"</Atom>";	
			var choice22 =
				"<Atom>" + "\n\t\t" +
			"<Rel>getDoctoralConsortiumPapers</Rel>" + "\n\t\t" +
                        "<Ind>accepted</Ind>" + "\n\t\t" +
			"<Var>DoctoralConsortiumPapers</Var>" + "\n\t    " +
			"</Atom>";	
			
    
 	 var messageHeader =
                  "<RuleML xmlns=\n   \"http://www.ruleml.org/0.91/xsd\"" + "\n" +
				  " xmlns:xsi=\n   \"http://www.w3.org/2001/XMLSchema-instance\"" + "\n" +
				  " xsi:schemaLocation=\n   \"http://www.ruleml.org/0.91/xsd" + "\n   " +
				  " http://ibis.in.tum.de/research/" + "\n    " + "ReactionRuleML/0.2/rr.xsd\"" + "\n" +
				  " xmlns:ruleml2011=" + "\n   " + "\"http://ibis.in.tum.de/projects/paw#\">" + "\n" +
				  "\n " + "<Message mode=\"outbound\"" + "\n  " + "directive=\"query-sync\">" +
			      "\n   " + "<oid>" + "\n      " + 
			      "<Ind>RuleML-2011-IJCAI</Ind>" + "\n   " +
			      "</oid>" + "\n   " +
			      "<protocol>" + "\n      " +
			      "<Ind>esb</Ind>" + "\n   " +
			      "</protocol>" + "\n   " +
			      "<sender>" + "\n      " +
			      "<Ind>User</Ind>" + "\n   " +
			      "</sender>" + "\n   " +
			      "<content>" + "\n      ";			
			

			
	 var messageFooter = 			     
				"   " + "</content>" + "\n " +
			      "</Message>" + "\n" +
			      "</RuleML>";
		
 
		if(choice == 0){
			document.form2.box1.value = messageHeader + choice0 + messageFooter;
		}else if(choice == 1){
			document.form2.box1.value = messageHeader + choice1 + messageFooter;
		}else if(choice == 2){
			document.form2.box1.value = messageHeader + choice2 + messageFooter;
		}else if(choice == 3){
			document.form2.box1.value = messageHeader + choice3 + messageFooter;
		}else if(choice == 4){
			document.form2.box1.value = messageHeader + choice4 + messageFooter;
		}else if(choice == 5){
			document.form2.box1.value = messageHeader + choice5 + messageFooter;
		}else if(choice == 6){
			document.form2.box1.value = messageHeader + choice6 + messageFooter;
		}else if(choice == 7){
			document.form2.box1.value = messageHeader + choice7 + messageFooter;
		}else if(choice == 8){
			document.form2.box1.value = messageHeader + choice8 + messageFooter;
		}else if(choice == 9){
			document.form2.box1.value = messageHeader + choice9 + messageFooter;
		}else if(choice == 10){
			document.form2.box1.value = messageHeader + choice10 + messageFooter;
		}else if(choice == 11){
			document.form2.box1.value = messageHeader + choice11 + messageFooter;
		}else if(choice == 12){
			document.form2.box1.value = messageHeader + choice12 + messageFooter;
		}else if(choice == 13){
			document.form2.box1.value = messageHeader + choice13 + messageFooter;
		}else if(choice == 14){
			document.form2.box1.value = messageHeader + choice14 + messageFooter;
		}else if(choice == 15){
			document.form2.box1.value = messageHeader + choice15 + messageFooter;
		}else if(choice == 16){
			document.form2.box1.value = messageHeader + choice16 + messageFooter;
		}else if(choice == 17){
			document.form2.box1.value = messageHeader + choice17 + messageFooter;
		}else if(choice == 18){
			document.form2.box1.value = messageHeader + choice18 + messageFooter;
		}else if(choice == 19){
			document.form2.box1.value = messageHeader + choice19 + messageFooter;
		}else if(choice == 20){
			document.form2.box1.value = messageHeader + choice20 + messageFooter;
		}else if(choice == 21){
			document.form2.box1.value = messageHeader + choice21 + messageFooter;
		}else if(choice == 22){
			document.form2.box1.value = messageHeader + choice22 + messageFooter;
		}
	}
	
	
	function elementSelected4(){
 
		var choice = document.form4.select4.selectedIndex;
	    //BRF 2011 general chair contact
		var choice0 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_GeneralChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
	    //publicity chair sponsoring
		var choice1 = 
			      "<Atom>" + "\n         " +
			      "<Rel>sponsor</Rel>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>contact</Fun>" + "\n            " +
				"<Ind>Mark</Ind>" + "\n            " +
				"<Ind>JBoss</Ind>" + "\n         " +
				"</Expr>" + "\n         " + 
			    "<Ind type=\"integer\">500</Ind>" + "\n         " +
				"<Expr>" + "\n            " +
				"<Fun>results</Fun>" + "\n            " +
				"<Var>Level</Var>" + "\n            " +
				"<Var>Benefits</Var>" + "\n            " +
				"<Var>DeadlineResults</Var>" + "\n         " +
				"</Expr>" + "\n         " + 
				"<Expr>" + "\n            " +
				"<Fun>performative</Fun>" + "\n            " +
				"<Var>Action</Var>" + "\n         " +
				"</Expr>" + "\n      " + 
			    "</Atom>" + "\n";
       //BRF 2011 publicity chair contact
	   var choice2 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_PublicityChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n"; 
	    //liaison chair view media partners
		var choice3 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewMediaPartners</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Partner</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//liaison chair view organization partners
		var choice4 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewOrganizationPartners</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Partner</Var>" + "\n      " + 
				"</Atom>" + "\n";
		
		//liaison chair view sponsors with regards to level
		var choice5 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewSponsors</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Company</Var>" + "\n         " + 
				"<Var>SponsorLevel</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
		//liaison chair view sponsors
		var choice6 = 		
				"<Atom>" + "\n         " +
			    "<Rel>viewSponsors</Rel>" + "\n         " + 
				"<Var>Meeting</Var>" + "\n         " + 
				"<Var>Company</Var>" + "\n      " + 
				"</Atom>" + "\n";
				
				  
		//BRF 2011 program chair contact
		var choice7 = 
			      "<Atom>" + "\n         " +
			      "<Rel>getContact</Rel>" + "\n         " + 
				"<Ind>ruleml2011ATbrf_ProgramChair</Ind>" + "\n         " +
				
			      "<Var>Contact</Var>" + "\n      " +
			      "</Atom>" + "\n";
	 	//Program Chair Retrieve Tracks
		var choice8 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTracks</Rel>" + "\n\t\t" +
			"<Var>Track</Var>" + "\n\t    " +
			"</Atom>";
			      
		var choice9 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTopicsOfATrack</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Rules and Norms</Ind>" + "\n\t\t" +
			"<Var>Topic</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve Track of a Topic
		var choice10 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTrackOfATopic</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">The relationship between rules and legal argumentation schemes</Ind>" + "\n\t\t" +
			"<Var>Track</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Find Tracks relevant to Keywords (string)
		var choice11 =
			"<Atom>" + "\n\t\t" +
			"<Rel>findTracks</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">defeasibility; rule exceptions</Ind>" + "\n\t\t" +
			"<Var>ScoredTrack</Var>" + "\n\t    " +
			"</Atom>";


	    //Program Chair Retrieve all Track Chairs
		var choice12 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getTrackChairs</Rel>" + "\n\t\t" +
			"<Var>TrackChairs</Var>" + "\n\t    " +
			"</Atom>";

	    //Program Chair Retrieve names of Chairs for specific Track
		var choice13 =
			"<Atom>" + "\n\t\t" +
			"<Rel>getChairsOfTrack</Rel>" + "\n\t\t" +
			"<Ind type=\"string\">Rules and Norms</Ind>" + "\n\t\t" +
			"<Var>Chairs</Var>" + "\n\t    " +
			"</Atom>";

				  
	 var messageHeader =
                  "<RuleML xmlns=\n   \"http://www.ruleml.org/0.91/xsd\"" + "\n" +
				  " xmlns:xsi=\n   \"http://www.w3.org/2001/XMLSchema-instance\"" + "\n" +
				  " xsi:schemaLocation=\n   \"http://www.ruleml.org/0.91/xsd" + "\n   " +
				  " http://ibis.in.tum.de/research/" + "\n    " + "ReactionRuleML/0.2/rr.xsd\"" + "\n" +
				  " xmlns:ruleml2011=" + "\n   " + "\"http://ibis.in.tum.de/projects/paw#\">" + "\n" +
				  "\n " + "<Message mode=\"outbound\"" + "\n  " + "directive=\"query-sync\">" +
			      "\n   " + "<oid>" + "\n      " + 
			      "<Ind>RuleML-2011-BRF</Ind>" + "\n   " +
			      "</oid>" + "\n   " +
			      "<protocol>" + "\n      " +
			      "<Ind>esb</Ind>" + "\n   " +
			      "</protocol>" + "\n   " +
			      "<sender>" + "\n      " +
			      "<Ind>User</Ind>" + "\n   " +
			      "</sender>" + "\n   " +
			      "<content>" + "\n      ";					
		
	 var messageFooter = 			     
				"   " + "</content>" + "\n " +
			      "</Message>" + "\n" +
			      "</RuleML>";
		
 
		if(choice == 0){
			document.form2.box1.value = messageHeader + choice0 + messageFooter;
		}else if(choice == 1){
			document.form2.box1.value = messageHeader + choice1 + messageFooter;
		}else if(choice == 2){
			document.form2.box1.value = messageHeader + choice2 + messageFooter;
		}else if(choice == 3){
			document.form2.box1.value = messageHeader + choice3 + messageFooter;
		}else if(choice == 4){
			document.form2.box1.value = messageHeader + choice4 + messageFooter;
		}else if(choice == 5){
			document.form2.box1.value = messageHeader + choice5 + messageFooter;
		}else if(choice == 6){
			document.form2.box1.value = messageHeader + choice6 + messageFooter;
		}else if(choice == 7){
			document.form2.box1.value = messageHeader + choice7 + messageFooter;
		}else if(choice == 8){
			document.form2.box1.value = messageHeader + choice8 + messageFooter;
		}else if(choice == 9){
			document.form2.box1.value = messageHeader + choice9 + messageFooter;
		}else if(choice == 10){
			document.form2.box1.value = messageHeader + choice10 + messageFooter;
		}else if(choice == 11){
			document.form2.box1.value = messageHeader + choice11 + messageFooter;
		}else if(choice == 12){
			document.form2.box1.value = messageHeader + choice12 + messageFooter;
		}else if(choice == 13){
			document.form2.box1.value = messageHeader + choice13 + messageFooter;
		}
	}
